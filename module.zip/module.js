var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
const CONSTANTS = {
  MODULE_NAME: "playlist_import",
  PATH: `modules/playlist_import/`
};
CONSTANTS.PATH = `modules/${CONSTANTS.MODULE_NAME}/`;
const registerSettings = /* @__PURE__ */ __name(function() {
  game.settings.register(CONSTANTS.MODULE_NAME, "songs", {
    name: `${CONSTANTS.MODULE_NAME}.Songs`,
    hint: `${CONSTANTS.MODULE_NAME}.SongsHint`,
    scope: "world",
    config: false,
    default: {},
    type: Object
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "bucket", {
    name: `${CONSTANTS.MODULE_NAME}.BucketSelect`,
    hint: `${CONSTANTS.MODULE_NAME}.BucketSelectHint`,
    scope: "world",
    config: true,
    default: "",
    type: String
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "shouldRepeat", {
    name: `${CONSTANTS.MODULE_NAME}.ShouldRepeat`,
    hint: `${CONSTANTS.MODULE_NAME}.ShouldRepeatHint`,
    scope: "world",
    config: true,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "shouldStream", {
    name: `${CONSTANTS.MODULE_NAME}.ShouldStream`,
    hint: `${CONSTANTS.MODULE_NAME}.ShouldStreamHint`,
    scope: "world",
    config: true,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "shouldUseNewFolderStructureCreation", {
    name: `${CONSTANTS.MODULE_NAME}.shouldUseNewFolderStructureCreation`,
    hint: `${CONSTANTS.MODULE_NAME}.shouldUseNewFolderStructureCreationHint`,
    scope: "world",
    config: true,
    default: true,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "folderDir", {
    name: `${CONSTANTS.MODULE_NAME}.FolderDir`,
    hint: `${CONSTANTS.MODULE_NAME}.FolderDirHint`,
    scope: "world",
    config: true,
    default: "music",
    type: String,
    filePicker: "folder"
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "fadeTime", {
    name: `${CONSTANTS.MODULE_NAME}.FadeTime`,
    hint: `${CONSTANTS.MODULE_NAME}.FadeTimeHint`,
    scope: "world",
    config: true,
    default: "0",
    type: String
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "logVolume", {
    name: `${CONSTANTS.MODULE_NAME}.LogVolume`,
    hint: `${CONSTANTS.MODULE_NAME}.LogVolumeHint`,
    scope: "world",
    config: true,
    default: "0.5",
    type: String
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "enableDuplicateChecking", {
    name: `${CONSTANTS.MODULE_NAME}.EnableDuplicate`,
    hint: `${CONSTANTS.MODULE_NAME}.EnableDuplicateHint`,
    scope: "world",
    config: true,
    default: true,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "customRegexDelete", {
    name: `${CONSTANTS.MODULE_NAME}.CustomRegexDelete`,
    hint: `${CONSTANTS.MODULE_NAME}.CustomRegexDeleteHint`,
    scope: "world",
    config: true,
    default: "^\\d\\d+ *_*-* *",
    type: String
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "shouldOverridePlaylist", {
    name: `${CONSTANTS.MODULE_NAME}.ShouldOverridePlaylist`,
    hint: `${CONSTANTS.MODULE_NAME}.ShouldOverridePlaylistHint`,
    scope: "world",
    config: true,
    default: true,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "source", {
    name: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.SelectSource`),
    hint: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.SelectSourceHint`),
    // hint: `${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.SelectSourceHint`)} [${options}]`,
    scope: "world",
    config: true,
    default: "data",
    type: String,
    // https://foundryvtt.wiki/en/development/api/settings
    choices: {
      data: "data",
      public: "public",
      s3: "s3"
    },
    onChange: (value) => {
      console.log(`DEBUG | ${CONSTANTS.MODULE_NAME} | Source setting value set to : ${value}`);
    }
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "shouldDeletePlaylist", {
    name: `${CONSTANTS.MODULE_NAME}.ShouldDeletePlaylist`,
    hint: `${CONSTANTS.MODULE_NAME}.ShouldDeletePlaylistHint`,
    scope: "world",
    config: true,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "maintainOriginalFolderName", {
    name: `${CONSTANTS.MODULE_NAME}.MaintainOriginalFolderName`,
    hint: `${CONSTANTS.MODULE_NAME}.MaintainOriginalFolderNameHint`,
    scope: "world",
    config: true,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "skipEmptyFolders", {
    name: `${CONSTANTS.MODULE_NAME}.SkipEmptyFolders`,
    hint: `${CONSTANTS.MODULE_NAME}.SkipEmptyFoldersHint`,
    scope: "world",
    config: true,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_NAME, "debug", {
    name: `${CONSTANTS.MODULE_NAME}.setting.debug.name`,
    hint: `${CONSTANTS.MODULE_NAME}.setting.debug.hint`,
    scope: "client",
    config: true,
    default: false,
    type: Boolean
  });
}, "registerSettings");
function debug(msg, args = "") {
  if (game.settings.get(CONSTANTS.MODULE_NAME, "debug")) {
    console.log(`DEBUG | ${CONSTANTS.MODULE_NAME} | ${msg}`, args);
  }
  return msg;
}
__name(debug, "debug");
function info(info2, notify = false) {
  info2 = `${CONSTANTS.MODULE_NAME} | ${info2}`;
  if (notify)
    ui.notifications?.info(info2);
  console.log(info2.replace("<br>", "\n"));
  return info2;
}
__name(info, "info");
function warn(warning, notify = false) {
  warning = `${CONSTANTS.MODULE_NAME} | ${warning}`;
  if (notify)
    ui.notifications?.warn(warning);
  console.warn(warning.replace("<br>", "\n"));
  return warning;
}
__name(warn, "warn");
function error(error2, notify = true) {
  error2 = `${CONSTANTS.MODULE_NAME} | ${error2}`;
  if (notify)
    ui.notifications?.error(error2);
  return new Error(error2.replace("<br>", "\n"));
}
__name(error, "error");
function debugListOfFilePicker(msg, list = [0]) {
  if (game.settings.get(CONSTANTS.MODULE_NAME, "debug")) {
    for (var index in list) {
      console.log(
        `DEBUG | ${CONSTANTS.MODULE_NAME} | ${msg} | list => element number ${index} : ${list[index].target}`
      );
    }
  }
  return msg;
}
__name(debugListOfFilePicker, "debugListOfFilePicker");
function createUploadFolderIfMissing(originFolder, uploadFolderPath) {
  return getFolder(originFolder, uploadFolderPath).then((location) => location.target === "." && createFolder(originFolder, uploadFolderPath)).catch(() => createFolder(originFolder, uploadFolderPath));
}
__name(createUploadFolderIfMissing, "createUploadFolderIfMissing");
function getFolder(source, target) {
  return foundry.applications.apps.FilePicker.implementation.browse(source, target);
}
__name(getFolder, "getFolder");
function createFolder(source, target, options = {}) {
  return foundry.applications.apps.FilePicker.implementation.createDirectory(source, target, options);
}
__name(createFolder, "createFolder");
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);
  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function(sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }
  return keys;
}
__name(ownKeys, "ownKeys");
function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), true).forEach(function(key) {
      _defineProperty(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }
  return target;
}
__name(_objectSpread2, "_objectSpread2");
function _typeof(obj) {
  "@babel/helpers - typeof";
  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
    return typeof obj2;
  } : function(obj2) {
    return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
  }, _typeof(obj);
}
__name(_typeof, "_typeof");
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
__name(_classCallCheck, "_classCallCheck");
function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor)
      descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}
__name(_defineProperties, "_defineProperties");
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps)
    _defineProperties(Constructor.prototype, protoProps);
  if (staticProps)
    _defineProperties(Constructor, staticProps);
  Object.defineProperty(Constructor, "prototype", {
    writable: false
  });
  return Constructor;
}
__name(_createClass, "_createClass");
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
__name(_defineProperty, "_defineProperty");
function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
__name(_slicedToArray, "_slicedToArray");
function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}
__name(_toConsumableArray, "_toConsumableArray");
function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr))
    return _arrayLikeToArray(arr);
}
__name(_arrayWithoutHoles, "_arrayWithoutHoles");
function _arrayWithHoles(arr) {
  if (Array.isArray(arr))
    return arr;
}
__name(_arrayWithHoles, "_arrayWithHoles");
function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null)
    return Array.from(iter);
}
__name(_iterableToArray, "_iterableToArray");
function _iterableToArrayLimit(arr, i) {
  var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
  if (_i == null)
    return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _s, _e;
  try {
    for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);
      if (i && _arr.length === i)
        break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null)
        _i["return"]();
    } finally {
      if (_d)
        throw _e;
    }
  }
  return _arr;
}
__name(_iterableToArrayLimit, "_iterableToArrayLimit");
function _unsupportedIterableToArray(o, minLen) {
  if (!o)
    return;
  if (typeof o === "string")
    return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor)
    n = o.constructor.name;
  if (n === "Map" || n === "Set")
    return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
    return _arrayLikeToArray(o, minLen);
}
__name(_unsupportedIterableToArray, "_unsupportedIterableToArray");
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length)
    len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++)
    arr2[i] = arr[i];
  return arr2;
}
__name(_arrayLikeToArray, "_arrayLikeToArray");
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
__name(_nonIterableSpread, "_nonIterableSpread");
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
__name(_nonIterableRest, "_nonIterableRest");
var noop = /* @__PURE__ */ __name(function noop2() {
}, "noop");
var _WINDOW = {};
var _DOCUMENT = {};
var _MUTATION_OBSERVER = null;
var _PERFORMANCE = {
  mark: noop,
  measure: noop
};
try {
  if (typeof window !== "undefined")
    _WINDOW = window;
  if (typeof document !== "undefined")
    _DOCUMENT = document;
  if (typeof MutationObserver !== "undefined")
    _MUTATION_OBSERVER = MutationObserver;
  if (typeof performance !== "undefined")
    _PERFORMANCE = performance;
} catch (e) {
}
var _ref = _WINDOW.navigator || {}, _ref$userAgent = _ref.userAgent, userAgent = _ref$userAgent === void 0 ? "" : _ref$userAgent;
var WINDOW = _WINDOW;
var DOCUMENT = _DOCUMENT;
var MUTATION_OBSERVER = _MUTATION_OBSERVER;
var PERFORMANCE = _PERFORMANCE;
!!WINDOW.document;
var IS_DOM = !!DOCUMENT.documentElement && !!DOCUMENT.head && typeof DOCUMENT.addEventListener === "function" && typeof DOCUMENT.createElement === "function";
var IS_IE = ~userAgent.indexOf("MSIE") || ~userAgent.indexOf("Trident/");
var _familyProxy, _familyProxy2, _familyProxy3, _familyProxy4, _familyProxy5;
var NAMESPACE_IDENTIFIER = "___FONT_AWESOME___";
var UNITS_IN_GRID = 16;
var DEFAULT_CSS_PREFIX = "fa";
var DEFAULT_REPLACEMENT_CLASS = "svg-inline--fa";
var DATA_FA_I2SVG = "data-fa-i2svg";
var DATA_FA_PSEUDO_ELEMENT = "data-fa-pseudo-element";
var DATA_FA_PSEUDO_ELEMENT_PENDING = "data-fa-pseudo-element-pending";
var DATA_PREFIX = "data-prefix";
var DATA_ICON = "data-icon";
var HTML_CLASS_I2SVG_BASE_CLASS = "fontawesome-i2svg";
var MUTATION_APPROACH_ASYNC = "async";
var TAGNAMES_TO_SKIP_FOR_PSEUDOELEMENTS = ["HTML", "HEAD", "STYLE", "SCRIPT"];
var PRODUCTION = function() {
  try {
    return process.env.NODE_ENV === "production";
  } catch (e) {
    return false;
  }
}();
var FAMILY_CLASSIC = "classic";
var FAMILY_SHARP = "sharp";
var FAMILIES = [FAMILY_CLASSIC, FAMILY_SHARP];
function familyProxy(obj) {
  return new Proxy(obj, {
    get: /* @__PURE__ */ __name(function get2(target, prop) {
      return prop in target ? target[prop] : target[FAMILY_CLASSIC];
    }, "get")
  });
}
__name(familyProxy, "familyProxy");
var PREFIX_TO_STYLE = familyProxy((_familyProxy = {}, _defineProperty(_familyProxy, FAMILY_CLASSIC, {
  "fa": "solid",
  "fas": "solid",
  "fa-solid": "solid",
  "far": "regular",
  "fa-regular": "regular",
  "fal": "light",
  "fa-light": "light",
  "fat": "thin",
  "fa-thin": "thin",
  "fad": "duotone",
  "fa-duotone": "duotone",
  "fab": "brands",
  "fa-brands": "brands",
  "fak": "kit",
  "fakd": "kit",
  "fa-kit": "kit",
  "fa-kit-duotone": "kit"
}), _defineProperty(_familyProxy, FAMILY_SHARP, {
  "fa": "solid",
  "fass": "solid",
  "fa-solid": "solid",
  "fasr": "regular",
  "fa-regular": "regular",
  "fasl": "light",
  "fa-light": "light",
  "fast": "thin",
  "fa-thin": "thin"
}), _familyProxy));
var STYLE_TO_PREFIX = familyProxy((_familyProxy2 = {}, _defineProperty(_familyProxy2, FAMILY_CLASSIC, {
  solid: "fas",
  regular: "far",
  light: "fal",
  thin: "fat",
  duotone: "fad",
  brands: "fab",
  kit: "fak"
}), _defineProperty(_familyProxy2, FAMILY_SHARP, {
  solid: "fass",
  regular: "fasr",
  light: "fasl",
  thin: "fast"
}), _familyProxy2));
var PREFIX_TO_LONG_STYLE = familyProxy((_familyProxy3 = {}, _defineProperty(_familyProxy3, FAMILY_CLASSIC, {
  fab: "fa-brands",
  fad: "fa-duotone",
  fak: "fa-kit",
  fal: "fa-light",
  far: "fa-regular",
  fas: "fa-solid",
  fat: "fa-thin"
}), _defineProperty(_familyProxy3, FAMILY_SHARP, {
  fass: "fa-solid",
  fasr: "fa-regular",
  fasl: "fa-light",
  fast: "fa-thin"
}), _familyProxy3));
var LONG_STYLE_TO_PREFIX = familyProxy((_familyProxy4 = {}, _defineProperty(_familyProxy4, FAMILY_CLASSIC, {
  "fa-brands": "fab",
  "fa-duotone": "fad",
  "fa-kit": "fak",
  "fa-light": "fal",
  "fa-regular": "far",
  "fa-solid": "fas",
  "fa-thin": "fat"
}), _defineProperty(_familyProxy4, FAMILY_SHARP, {
  "fa-solid": "fass",
  "fa-regular": "fasr",
  "fa-light": "fasl",
  "fa-thin": "fast"
}), _familyProxy4));
var ICON_SELECTION_SYNTAX_PATTERN = /fa(s|r|l|t|d|b|k|ss|sr|sl|st)?[\-\ ]/;
var LAYERS_TEXT_CLASSNAME = "fa-layers-text";
var FONT_FAMILY_PATTERN = /Font ?Awesome ?([56 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp|Kit)?.*/i;
var FONT_WEIGHT_TO_PREFIX = familyProxy((_familyProxy5 = {}, _defineProperty(_familyProxy5, FAMILY_CLASSIC, {
  900: "fas",
  400: "far",
  normal: "far",
  300: "fal",
  100: "fat"
}), _defineProperty(_familyProxy5, FAMILY_SHARP, {
  900: "fass",
  400: "fasr",
  300: "fasl",
  100: "fast"
}), _familyProxy5));
var oneToTen = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var oneToTwenty = oneToTen.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]);
var ATTRIBUTES_WATCHED_FOR_MUTATION = ["class", "data-prefix", "data-icon", "data-fa-transform", "data-fa-mask"];
var DUOTONE_CLASSES = {
  GROUP: "duotone-group",
  SWAP_OPACITY: "swap-opacity",
  PRIMARY: "primary",
  SECONDARY: "secondary"
};
var prefixes = /* @__PURE__ */ new Set();
Object.keys(STYLE_TO_PREFIX[FAMILY_CLASSIC]).map(prefixes.add.bind(prefixes));
Object.keys(STYLE_TO_PREFIX[FAMILY_SHARP]).map(prefixes.add.bind(prefixes));
var RESERVED_CLASSES = [].concat(FAMILIES, _toConsumableArray(prefixes), ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "border", "fade", "beat-fade", "bounce", "flip-both", "flip-horizontal", "flip-vertical", "flip", "fw", "inverse", "layers-counter", "layers-text", "layers", "li", "pull-left", "pull-right", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "stack-1x", "stack-2x", "stack", "ul", DUOTONE_CLASSES.GROUP, DUOTONE_CLASSES.SWAP_OPACITY, DUOTONE_CLASSES.PRIMARY, DUOTONE_CLASSES.SECONDARY]).concat(oneToTen.map(function(n) {
  return "".concat(n, "x");
})).concat(oneToTwenty.map(function(n) {
  return "w-".concat(n);
}));
var initial = WINDOW.FontAwesomeConfig || {};
function getAttrConfig(attr) {
  var element = DOCUMENT.querySelector("script[" + attr + "]");
  if (element) {
    return element.getAttribute(attr);
  }
}
__name(getAttrConfig, "getAttrConfig");
function coerce(val) {
  if (val === "")
    return true;
  if (val === "false")
    return false;
  if (val === "true")
    return true;
  return val;
}
__name(coerce, "coerce");
if (DOCUMENT && typeof DOCUMENT.querySelector === "function") {
  var attrs = [["data-family-prefix", "familyPrefix"], ["data-css-prefix", "cssPrefix"], ["data-family-default", "familyDefault"], ["data-style-default", "styleDefault"], ["data-replacement-class", "replacementClass"], ["data-auto-replace-svg", "autoReplaceSvg"], ["data-auto-add-css", "autoAddCss"], ["data-auto-a11y", "autoA11y"], ["data-search-pseudo-elements", "searchPseudoElements"], ["data-observe-mutations", "observeMutations"], ["data-mutate-approach", "mutateApproach"], ["data-keep-original-source", "keepOriginalSource"], ["data-measure-performance", "measurePerformance"], ["data-show-missing-icons", "showMissingIcons"]];
  attrs.forEach(function(_ref2) {
    var _ref22 = _slicedToArray(_ref2, 2), attr = _ref22[0], key = _ref22[1];
    var val = coerce(getAttrConfig(attr));
    if (val !== void 0 && val !== null) {
      initial[key] = val;
    }
  });
}
var _default = {
  styleDefault: "solid",
  familyDefault: "classic",
  cssPrefix: DEFAULT_CSS_PREFIX,
  replacementClass: DEFAULT_REPLACEMENT_CLASS,
  autoReplaceSvg: true,
  autoAddCss: true,
  autoA11y: true,
  searchPseudoElements: false,
  observeMutations: true,
  mutateApproach: "async",
  keepOriginalSource: true,
  measurePerformance: false,
  showMissingIcons: true
};
if (initial.familyPrefix) {
  initial.cssPrefix = initial.familyPrefix;
}
var _config = _objectSpread2(_objectSpread2({}, _default), initial);
if (!_config.autoReplaceSvg)
  _config.observeMutations = false;
var config = {};
Object.keys(_default).forEach(function(key) {
  Object.defineProperty(config, key, {
    enumerable: true,
    set: /* @__PURE__ */ __name(function set2(val) {
      _config[key] = val;
      _onChangeCb.forEach(function(cb) {
        return cb(config);
      });
    }, "set"),
    get: /* @__PURE__ */ __name(function get2() {
      return _config[key];
    }, "get")
  });
});
Object.defineProperty(config, "familyPrefix", {
  enumerable: true,
  set: /* @__PURE__ */ __name(function set(val) {
    _config.cssPrefix = val;
    _onChangeCb.forEach(function(cb) {
      return cb(config);
    });
  }, "set"),
  get: /* @__PURE__ */ __name(function get() {
    return _config.cssPrefix;
  }, "get")
});
WINDOW.FontAwesomeConfig = config;
var _onChangeCb = [];
function onChange(cb) {
  _onChangeCb.push(cb);
  return function() {
    _onChangeCb.splice(_onChangeCb.indexOf(cb), 1);
  };
}
__name(onChange, "onChange");
var d = UNITS_IN_GRID;
var meaninglessTransform = {
  size: 16,
  x: 0,
  y: 0,
  rotate: 0,
  flipX: false,
  flipY: false
};
function insertCss(css2) {
  if (!css2 || !IS_DOM) {
    return;
  }
  var style = DOCUMENT.createElement("style");
  style.setAttribute("type", "text/css");
  style.innerHTML = css2;
  var headChildren = DOCUMENT.head.childNodes;
  var beforeChild = null;
  for (var i = headChildren.length - 1; i > -1; i--) {
    var child = headChildren[i];
    var tagName = (child.tagName || "").toUpperCase();
    if (["STYLE", "LINK"].indexOf(tagName) > -1) {
      beforeChild = child;
    }
  }
  DOCUMENT.head.insertBefore(style, beforeChild);
  return css2;
}
__name(insertCss, "insertCss");
var idPool = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
function nextUniqueId() {
  var size = 12;
  var id = "";
  while (size-- > 0) {
    id += idPool[Math.random() * 62 | 0];
  }
  return id;
}
__name(nextUniqueId, "nextUniqueId");
function toArray(obj) {
  var array = [];
  for (var i = (obj || []).length >>> 0; i--; ) {
    array[i] = obj[i];
  }
  return array;
}
__name(toArray, "toArray");
function classArray(node) {
  if (node.classList) {
    return toArray(node.classList);
  } else {
    return (node.getAttribute("class") || "").split(" ").filter(function(i) {
      return i;
    });
  }
}
__name(classArray, "classArray");
function htmlEscape(str) {
  return "".concat(str).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
__name(htmlEscape, "htmlEscape");
function joinAttributes(attributes) {
  return Object.keys(attributes || {}).reduce(function(acc, attributeName) {
    return acc + "".concat(attributeName, '="').concat(htmlEscape(attributes[attributeName]), '" ');
  }, "").trim();
}
__name(joinAttributes, "joinAttributes");
function joinStyles(styles2) {
  return Object.keys(styles2 || {}).reduce(function(acc, styleName) {
    return acc + "".concat(styleName, ": ").concat(styles2[styleName].trim(), ";");
  }, "");
}
__name(joinStyles, "joinStyles");
function transformIsMeaningful(transform) {
  return transform.size !== meaninglessTransform.size || transform.x !== meaninglessTransform.x || transform.y !== meaninglessTransform.y || transform.rotate !== meaninglessTransform.rotate || transform.flipX || transform.flipY;
}
__name(transformIsMeaningful, "transformIsMeaningful");
function transformForSvg(_ref2) {
  var transform = _ref2.transform, containerWidth = _ref2.containerWidth, iconWidth = _ref2.iconWidth;
  var outer = {
    transform: "translate(".concat(containerWidth / 2, " 256)")
  };
  var innerTranslate = "translate(".concat(transform.x * 32, ", ").concat(transform.y * 32, ") ");
  var innerScale = "scale(".concat(transform.size / 16 * (transform.flipX ? -1 : 1), ", ").concat(transform.size / 16 * (transform.flipY ? -1 : 1), ") ");
  var innerRotate = "rotate(".concat(transform.rotate, " 0 0)");
  var inner = {
    transform: "".concat(innerTranslate, " ").concat(innerScale, " ").concat(innerRotate)
  };
  var path = {
    transform: "translate(".concat(iconWidth / 2 * -1, " -256)")
  };
  return {
    outer,
    inner,
    path
  };
}
__name(transformForSvg, "transformForSvg");
function transformForCss(_ref2) {
  var transform = _ref2.transform, _ref2$width = _ref2.width, width = _ref2$width === void 0 ? UNITS_IN_GRID : _ref2$width, _ref2$height = _ref2.height, height = _ref2$height === void 0 ? UNITS_IN_GRID : _ref2$height, _ref2$startCentered = _ref2.startCentered, startCentered = _ref2$startCentered === void 0 ? false : _ref2$startCentered;
  var val = "";
  if (startCentered && IS_IE) {
    val += "translate(".concat(transform.x / d - width / 2, "em, ").concat(transform.y / d - height / 2, "em) ");
  } else if (startCentered) {
    val += "translate(calc(-50% + ".concat(transform.x / d, "em), calc(-50% + ").concat(transform.y / d, "em)) ");
  } else {
    val += "translate(".concat(transform.x / d, "em, ").concat(transform.y / d, "em) ");
  }
  val += "scale(".concat(transform.size / d * (transform.flipX ? -1 : 1), ", ").concat(transform.size / d * (transform.flipY ? -1 : 1), ") ");
  val += "rotate(".concat(transform.rotate, "deg) ");
  return val;
}
__name(transformForCss, "transformForCss");
var baseStyles = ':root, :host {\n  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Solid";\n  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Regular";\n  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Light";\n  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Thin";\n  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";\n  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";\n  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";\n  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";\n  --fa-font-sharp-thin: normal 100 1em/1 "Font Awesome 6 Sharp";\n  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";\n}\n\nsvg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {\n  overflow: visible;\n  box-sizing: content-box;\n}\n\n.svg-inline--fa {\n  display: var(--fa-display, inline-block);\n  height: 1em;\n  overflow: visible;\n  vertical-align: -0.125em;\n}\n.svg-inline--fa.fa-2xs {\n  vertical-align: 0.1em;\n}\n.svg-inline--fa.fa-xs {\n  vertical-align: 0em;\n}\n.svg-inline--fa.fa-sm {\n  vertical-align: -0.0714285705em;\n}\n.svg-inline--fa.fa-lg {\n  vertical-align: -0.2em;\n}\n.svg-inline--fa.fa-xl {\n  vertical-align: -0.25em;\n}\n.svg-inline--fa.fa-2xl {\n  vertical-align: -0.3125em;\n}\n.svg-inline--fa.fa-pull-left {\n  margin-right: var(--fa-pull-margin, 0.3em);\n  width: auto;\n}\n.svg-inline--fa.fa-pull-right {\n  margin-left: var(--fa-pull-margin, 0.3em);\n  width: auto;\n}\n.svg-inline--fa.fa-li {\n  width: var(--fa-li-width, 2em);\n  top: 0.25em;\n}\n.svg-inline--fa.fa-fw {\n  width: var(--fa-fw-width, 1.25em);\n}\n\n.fa-layers svg.svg-inline--fa {\n  bottom: 0;\n  left: 0;\n  margin: auto;\n  position: absolute;\n  right: 0;\n  top: 0;\n}\n\n.fa-layers-counter, .fa-layers-text {\n  display: inline-block;\n  position: absolute;\n  text-align: center;\n}\n\n.fa-layers {\n  display: inline-block;\n  height: 1em;\n  position: relative;\n  text-align: center;\n  vertical-align: -0.125em;\n  width: 1em;\n}\n.fa-layers svg.svg-inline--fa {\n  -webkit-transform-origin: center center;\n          transform-origin: center center;\n}\n\n.fa-layers-text {\n  left: 50%;\n  top: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  -webkit-transform-origin: center center;\n          transform-origin: center center;\n}\n\n.fa-layers-counter {\n  background-color: var(--fa-counter-background-color, #ff253a);\n  border-radius: var(--fa-counter-border-radius, 1em);\n  box-sizing: border-box;\n  color: var(--fa-inverse, #fff);\n  line-height: var(--fa-counter-line-height, 1);\n  max-width: var(--fa-counter-max-width, 5em);\n  min-width: var(--fa-counter-min-width, 1.5em);\n  overflow: hidden;\n  padding: var(--fa-counter-padding, 0.25em 0.5em);\n  right: var(--fa-right, 0);\n  text-overflow: ellipsis;\n  top: var(--fa-top, 0);\n  -webkit-transform: scale(var(--fa-counter-scale, 0.25));\n          transform: scale(var(--fa-counter-scale, 0.25));\n  -webkit-transform-origin: top right;\n          transform-origin: top right;\n}\n\n.fa-layers-bottom-right {\n  bottom: var(--fa-bottom, 0);\n  right: var(--fa-right, 0);\n  top: auto;\n  -webkit-transform: scale(var(--fa-layers-scale, 0.25));\n          transform: scale(var(--fa-layers-scale, 0.25));\n  -webkit-transform-origin: bottom right;\n          transform-origin: bottom right;\n}\n\n.fa-layers-bottom-left {\n  bottom: var(--fa-bottom, 0);\n  left: var(--fa-left, 0);\n  right: auto;\n  top: auto;\n  -webkit-transform: scale(var(--fa-layers-scale, 0.25));\n          transform: scale(var(--fa-layers-scale, 0.25));\n  -webkit-transform-origin: bottom left;\n          transform-origin: bottom left;\n}\n\n.fa-layers-top-right {\n  top: var(--fa-top, 0);\n  right: var(--fa-right, 0);\n  -webkit-transform: scale(var(--fa-layers-scale, 0.25));\n          transform: scale(var(--fa-layers-scale, 0.25));\n  -webkit-transform-origin: top right;\n          transform-origin: top right;\n}\n\n.fa-layers-top-left {\n  left: var(--fa-left, 0);\n  right: auto;\n  top: var(--fa-top, 0);\n  -webkit-transform: scale(var(--fa-layers-scale, 0.25));\n          transform: scale(var(--fa-layers-scale, 0.25));\n  -webkit-transform-origin: top left;\n          transform-origin: top left;\n}\n\n.fa-1x {\n  font-size: 1em;\n}\n\n.fa-2x {\n  font-size: 2em;\n}\n\n.fa-3x {\n  font-size: 3em;\n}\n\n.fa-4x {\n  font-size: 4em;\n}\n\n.fa-5x {\n  font-size: 5em;\n}\n\n.fa-6x {\n  font-size: 6em;\n}\n\n.fa-7x {\n  font-size: 7em;\n}\n\n.fa-8x {\n  font-size: 8em;\n}\n\n.fa-9x {\n  font-size: 9em;\n}\n\n.fa-10x {\n  font-size: 10em;\n}\n\n.fa-2xs {\n  font-size: 0.625em;\n  line-height: 0.1em;\n  vertical-align: 0.225em;\n}\n\n.fa-xs {\n  font-size: 0.75em;\n  line-height: 0.0833333337em;\n  vertical-align: 0.125em;\n}\n\n.fa-sm {\n  font-size: 0.875em;\n  line-height: 0.0714285718em;\n  vertical-align: 0.0535714295em;\n}\n\n.fa-lg {\n  font-size: 1.25em;\n  line-height: 0.05em;\n  vertical-align: -0.075em;\n}\n\n.fa-xl {\n  font-size: 1.5em;\n  line-height: 0.0416666682em;\n  vertical-align: -0.125em;\n}\n\n.fa-2xl {\n  font-size: 2em;\n  line-height: 0.03125em;\n  vertical-align: -0.1875em;\n}\n\n.fa-fw {\n  text-align: center;\n  width: 1.25em;\n}\n\n.fa-ul {\n  list-style-type: none;\n  margin-left: var(--fa-li-margin, 2.5em);\n  padding-left: 0;\n}\n.fa-ul > li {\n  position: relative;\n}\n\n.fa-li {\n  left: calc(var(--fa-li-width, 2em) * -1);\n  position: absolute;\n  text-align: center;\n  width: var(--fa-li-width, 2em);\n  line-height: inherit;\n}\n\n.fa-border {\n  border-color: var(--fa-border-color, #eee);\n  border-radius: var(--fa-border-radius, 0.1em);\n  border-style: var(--fa-border-style, solid);\n  border-width: var(--fa-border-width, 0.08em);\n  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);\n}\n\n.fa-pull-left {\n  float: left;\n  margin-right: var(--fa-pull-margin, 0.3em);\n}\n\n.fa-pull-right {\n  float: right;\n  margin-left: var(--fa-pull-margin, 0.3em);\n}\n\n.fa-beat {\n  -webkit-animation-name: fa-beat;\n          animation-name: fa-beat;\n  -webkit-animation-delay: var(--fa-animation-delay, 0s);\n          animation-delay: var(--fa-animation-delay, 0s);\n  -webkit-animation-direction: var(--fa-animation-direction, normal);\n          animation-direction: var(--fa-animation-direction, normal);\n  -webkit-animation-duration: var(--fa-animation-duration, 1s);\n          animation-duration: var(--fa-animation-duration, 1s);\n  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n          animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);\n          animation-timing-function: var(--fa-animation-timing, ease-in-out);\n}\n\n.fa-bounce {\n  -webkit-animation-name: fa-bounce;\n          animation-name: fa-bounce;\n  -webkit-animation-delay: var(--fa-animation-delay, 0s);\n          animation-delay: var(--fa-animation-delay, 0s);\n  -webkit-animation-direction: var(--fa-animation-direction, normal);\n          animation-direction: var(--fa-animation-direction, normal);\n  -webkit-animation-duration: var(--fa-animation-duration, 1s);\n          animation-duration: var(--fa-animation-duration, 1s);\n  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n          animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));\n          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));\n}\n\n.fa-fade {\n  -webkit-animation-name: fa-fade;\n          animation-name: fa-fade;\n  -webkit-animation-delay: var(--fa-animation-delay, 0s);\n          animation-delay: var(--fa-animation-delay, 0s);\n  -webkit-animation-direction: var(--fa-animation-direction, normal);\n          animation-direction: var(--fa-animation-direction, normal);\n  -webkit-animation-duration: var(--fa-animation-duration, 1s);\n          animation-duration: var(--fa-animation-duration, 1s);\n  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n          animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n}\n\n.fa-beat-fade {\n  -webkit-animation-name: fa-beat-fade;\n          animation-name: fa-beat-fade;\n  -webkit-animation-delay: var(--fa-animation-delay, 0s);\n          animation-delay: var(--fa-animation-delay, 0s);\n  -webkit-animation-direction: var(--fa-animation-direction, normal);\n          animation-direction: var(--fa-animation-direction, normal);\n  -webkit-animation-duration: var(--fa-animation-duration, 1s);\n          animation-duration: var(--fa-animation-duration, 1s);\n  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n          animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n}\n\n.fa-flip {\n  -webkit-animation-name: fa-flip;\n          animation-name: fa-flip;\n  -webkit-animation-delay: var(--fa-animation-delay, 0s);\n          animation-delay: var(--fa-animation-delay, 0s);\n  -webkit-animation-direction: var(--fa-animation-direction, normal);\n          animation-direction: var(--fa-animation-direction, normal);\n  -webkit-animation-duration: var(--fa-animation-duration, 1s);\n          animation-duration: var(--fa-animation-duration, 1s);\n  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n          animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);\n          animation-timing-function: var(--fa-animation-timing, ease-in-out);\n}\n\n.fa-shake {\n  -webkit-animation-name: fa-shake;\n          animation-name: fa-shake;\n  -webkit-animation-delay: var(--fa-animation-delay, 0s);\n          animation-delay: var(--fa-animation-delay, 0s);\n  -webkit-animation-direction: var(--fa-animation-direction, normal);\n          animation-direction: var(--fa-animation-direction, normal);\n  -webkit-animation-duration: var(--fa-animation-duration, 1s);\n          animation-duration: var(--fa-animation-duration, 1s);\n  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n          animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  -webkit-animation-timing-function: var(--fa-animation-timing, linear);\n          animation-timing-function: var(--fa-animation-timing, linear);\n}\n\n.fa-spin {\n  -webkit-animation-name: fa-spin;\n          animation-name: fa-spin;\n  -webkit-animation-delay: var(--fa-animation-delay, 0s);\n          animation-delay: var(--fa-animation-delay, 0s);\n  -webkit-animation-direction: var(--fa-animation-direction, normal);\n          animation-direction: var(--fa-animation-direction, normal);\n  -webkit-animation-duration: var(--fa-animation-duration, 2s);\n          animation-duration: var(--fa-animation-duration, 2s);\n  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n          animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  -webkit-animation-timing-function: var(--fa-animation-timing, linear);\n          animation-timing-function: var(--fa-animation-timing, linear);\n}\n\n.fa-spin-reverse {\n  --fa-animation-direction: reverse;\n}\n\n.fa-pulse,\n.fa-spin-pulse {\n  -webkit-animation-name: fa-spin;\n          animation-name: fa-spin;\n  -webkit-animation-direction: var(--fa-animation-direction, normal);\n          animation-direction: var(--fa-animation-direction, normal);\n  -webkit-animation-duration: var(--fa-animation-duration, 1s);\n          animation-duration: var(--fa-animation-duration, 1s);\n  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n          animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  -webkit-animation-timing-function: var(--fa-animation-timing, steps(8));\n          animation-timing-function: var(--fa-animation-timing, steps(8));\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .fa-beat,\n.fa-bounce,\n.fa-fade,\n.fa-beat-fade,\n.fa-flip,\n.fa-pulse,\n.fa-shake,\n.fa-spin,\n.fa-spin-pulse {\n    -webkit-animation-delay: -1ms;\n            animation-delay: -1ms;\n    -webkit-animation-duration: 1ms;\n            animation-duration: 1ms;\n    -webkit-animation-iteration-count: 1;\n            animation-iteration-count: 1;\n    -webkit-transition-delay: 0s;\n            transition-delay: 0s;\n    -webkit-transition-duration: 0s;\n            transition-duration: 0s;\n  }\n}\n@-webkit-keyframes fa-beat {\n  0%, 90% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n  45% {\n    -webkit-transform: scale(var(--fa-beat-scale, 1.25));\n            transform: scale(var(--fa-beat-scale, 1.25));\n  }\n}\n@keyframes fa-beat {\n  0%, 90% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n  45% {\n    -webkit-transform: scale(var(--fa-beat-scale, 1.25));\n            transform: scale(var(--fa-beat-scale, 1.25));\n  }\n}\n@-webkit-keyframes fa-bounce {\n  0% {\n    -webkit-transform: scale(1, 1) translateY(0);\n            transform: scale(1, 1) translateY(0);\n  }\n  10% {\n    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);\n            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);\n  }\n  30% {\n    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));\n            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));\n  }\n  50% {\n    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);\n            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);\n  }\n  57% {\n    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));\n            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));\n  }\n  64% {\n    -webkit-transform: scale(1, 1) translateY(0);\n            transform: scale(1, 1) translateY(0);\n  }\n  100% {\n    -webkit-transform: scale(1, 1) translateY(0);\n            transform: scale(1, 1) translateY(0);\n  }\n}\n@keyframes fa-bounce {\n  0% {\n    -webkit-transform: scale(1, 1) translateY(0);\n            transform: scale(1, 1) translateY(0);\n  }\n  10% {\n    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);\n            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);\n  }\n  30% {\n    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));\n            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));\n  }\n  50% {\n    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);\n            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);\n  }\n  57% {\n    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));\n            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));\n  }\n  64% {\n    -webkit-transform: scale(1, 1) translateY(0);\n            transform: scale(1, 1) translateY(0);\n  }\n  100% {\n    -webkit-transform: scale(1, 1) translateY(0);\n            transform: scale(1, 1) translateY(0);\n  }\n}\n@-webkit-keyframes fa-fade {\n  50% {\n    opacity: var(--fa-fade-opacity, 0.4);\n  }\n}\n@keyframes fa-fade {\n  50% {\n    opacity: var(--fa-fade-opacity, 0.4);\n  }\n}\n@-webkit-keyframes fa-beat-fade {\n  0%, 100% {\n    opacity: var(--fa-beat-fade-opacity, 0.4);\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n  50% {\n    opacity: 1;\n    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));\n            transform: scale(var(--fa-beat-fade-scale, 1.125));\n  }\n}\n@keyframes fa-beat-fade {\n  0%, 100% {\n    opacity: var(--fa-beat-fade-opacity, 0.4);\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n  50% {\n    opacity: 1;\n    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));\n            transform: scale(var(--fa-beat-fade-scale, 1.125));\n  }\n}\n@-webkit-keyframes fa-flip {\n  50% {\n    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));\n            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));\n  }\n}\n@keyframes fa-flip {\n  50% {\n    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));\n            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));\n  }\n}\n@-webkit-keyframes fa-shake {\n  0% {\n    -webkit-transform: rotate(-15deg);\n            transform: rotate(-15deg);\n  }\n  4% {\n    -webkit-transform: rotate(15deg);\n            transform: rotate(15deg);\n  }\n  8%, 24% {\n    -webkit-transform: rotate(-18deg);\n            transform: rotate(-18deg);\n  }\n  12%, 28% {\n    -webkit-transform: rotate(18deg);\n            transform: rotate(18deg);\n  }\n  16% {\n    -webkit-transform: rotate(-22deg);\n            transform: rotate(-22deg);\n  }\n  20% {\n    -webkit-transform: rotate(22deg);\n            transform: rotate(22deg);\n  }\n  32% {\n    -webkit-transform: rotate(-12deg);\n            transform: rotate(-12deg);\n  }\n  36% {\n    -webkit-transform: rotate(12deg);\n            transform: rotate(12deg);\n  }\n  40%, 100% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n}\n@keyframes fa-shake {\n  0% {\n    -webkit-transform: rotate(-15deg);\n            transform: rotate(-15deg);\n  }\n  4% {\n    -webkit-transform: rotate(15deg);\n            transform: rotate(15deg);\n  }\n  8%, 24% {\n    -webkit-transform: rotate(-18deg);\n            transform: rotate(-18deg);\n  }\n  12%, 28% {\n    -webkit-transform: rotate(18deg);\n            transform: rotate(18deg);\n  }\n  16% {\n    -webkit-transform: rotate(-22deg);\n            transform: rotate(-22deg);\n  }\n  20% {\n    -webkit-transform: rotate(22deg);\n            transform: rotate(22deg);\n  }\n  32% {\n    -webkit-transform: rotate(-12deg);\n            transform: rotate(-12deg);\n  }\n  36% {\n    -webkit-transform: rotate(12deg);\n            transform: rotate(12deg);\n  }\n  40%, 100% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n}\n@-webkit-keyframes fa-spin {\n  0% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n  }\n}\n@keyframes fa-spin {\n  0% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n  }\n}\n.fa-rotate-90 {\n  -webkit-transform: rotate(90deg);\n          transform: rotate(90deg);\n}\n\n.fa-rotate-180 {\n  -webkit-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n\n.fa-rotate-270 {\n  -webkit-transform: rotate(270deg);\n          transform: rotate(270deg);\n}\n\n.fa-flip-horizontal {\n  -webkit-transform: scale(-1, 1);\n          transform: scale(-1, 1);\n}\n\n.fa-flip-vertical {\n  -webkit-transform: scale(1, -1);\n          transform: scale(1, -1);\n}\n\n.fa-flip-both,\n.fa-flip-horizontal.fa-flip-vertical {\n  -webkit-transform: scale(-1, -1);\n          transform: scale(-1, -1);\n}\n\n.fa-rotate-by {\n  -webkit-transform: rotate(var(--fa-rotate-angle, 0));\n          transform: rotate(var(--fa-rotate-angle, 0));\n}\n\n.fa-stack {\n  display: inline-block;\n  vertical-align: middle;\n  height: 2em;\n  position: relative;\n  width: 2.5em;\n}\n\n.fa-stack-1x,\n.fa-stack-2x {\n  bottom: 0;\n  left: 0;\n  margin: auto;\n  position: absolute;\n  right: 0;\n  top: 0;\n  z-index: var(--fa-stack-z-index, auto);\n}\n\n.svg-inline--fa.fa-stack-1x {\n  height: 1em;\n  width: 1.25em;\n}\n.svg-inline--fa.fa-stack-2x {\n  height: 2em;\n  width: 2.5em;\n}\n\n.fa-inverse {\n  color: var(--fa-inverse, #fff);\n}\n\n.sr-only,\n.fa-sr-only {\n  position: absolute;\n  width: 1px;\n  height: 1px;\n  padding: 0;\n  margin: -1px;\n  overflow: hidden;\n  clip: rect(0, 0, 0, 0);\n  white-space: nowrap;\n  border-width: 0;\n}\n\n.sr-only-focusable:not(:focus),\n.fa-sr-only-focusable:not(:focus) {\n  position: absolute;\n  width: 1px;\n  height: 1px;\n  padding: 0;\n  margin: -1px;\n  overflow: hidden;\n  clip: rect(0, 0, 0, 0);\n  white-space: nowrap;\n  border-width: 0;\n}\n\n.svg-inline--fa .fa-primary {\n  fill: var(--fa-primary-color, currentColor);\n  opacity: var(--fa-primary-opacity, 1);\n}\n\n.svg-inline--fa .fa-secondary {\n  fill: var(--fa-secondary-color, currentColor);\n  opacity: var(--fa-secondary-opacity, 0.4);\n}\n\n.svg-inline--fa.fa-swap-opacity .fa-primary {\n  opacity: var(--fa-secondary-opacity, 0.4);\n}\n\n.svg-inline--fa.fa-swap-opacity .fa-secondary {\n  opacity: var(--fa-primary-opacity, 1);\n}\n\n.svg-inline--fa mask .fa-primary,\n.svg-inline--fa mask .fa-secondary {\n  fill: black;\n}\n\n.fad.fa-inverse,\n.fa-duotone.fa-inverse {\n  color: var(--fa-inverse, #fff);\n}';
function css() {
  var dcp = DEFAULT_CSS_PREFIX;
  var drc = DEFAULT_REPLACEMENT_CLASS;
  var fp = config.cssPrefix;
  var rc = config.replacementClass;
  var s = baseStyles;
  if (fp !== dcp || rc !== drc) {
    var dPatt = new RegExp("\\.".concat(dcp, "\\-"), "g");
    var customPropPatt = new RegExp("\\--".concat(dcp, "\\-"), "g");
    var rPatt = new RegExp("\\.".concat(drc), "g");
    s = s.replace(dPatt, ".".concat(fp, "-")).replace(customPropPatt, "--".concat(fp, "-")).replace(rPatt, ".".concat(rc));
  }
  return s;
}
__name(css, "css");
var _cssInserted = false;
function ensureCss() {
  if (config.autoAddCss && !_cssInserted) {
    insertCss(css());
    _cssInserted = true;
  }
}
__name(ensureCss, "ensureCss");
var InjectCSS = {
  mixout: /* @__PURE__ */ __name(function mixout() {
    return {
      dom: {
        css,
        insertCss: ensureCss
      }
    };
  }, "mixout"),
  hooks: /* @__PURE__ */ __name(function hooks() {
    return {
      beforeDOMElementCreation: /* @__PURE__ */ __name(function beforeDOMElementCreation() {
        ensureCss();
      }, "beforeDOMElementCreation"),
      beforeI2svg: /* @__PURE__ */ __name(function beforeI2svg() {
        ensureCss();
      }, "beforeI2svg")
    };
  }, "hooks")
};
var w = WINDOW || {};
if (!w[NAMESPACE_IDENTIFIER])
  w[NAMESPACE_IDENTIFIER] = {};
if (!w[NAMESPACE_IDENTIFIER].styles)
  w[NAMESPACE_IDENTIFIER].styles = {};
if (!w[NAMESPACE_IDENTIFIER].hooks)
  w[NAMESPACE_IDENTIFIER].hooks = {};
if (!w[NAMESPACE_IDENTIFIER].shims)
  w[NAMESPACE_IDENTIFIER].shims = [];
var namespace = w[NAMESPACE_IDENTIFIER];
var functions = [];
var listener = /* @__PURE__ */ __name(function listener2() {
  DOCUMENT.removeEventListener("DOMContentLoaded", listener2);
  loaded = 1;
  functions.map(function(fn) {
    return fn();
  });
}, "listener");
var loaded = false;
if (IS_DOM) {
  loaded = (DOCUMENT.documentElement.doScroll ? /^loaded|^c/ : /^loaded|^i|^c/).test(DOCUMENT.readyState);
  if (!loaded)
    DOCUMENT.addEventListener("DOMContentLoaded", listener);
}
function domready(fn) {
  if (!IS_DOM)
    return;
  loaded ? setTimeout(fn, 0) : functions.push(fn);
}
__name(domready, "domready");
function toHtml(abstractNodes) {
  var tag = abstractNodes.tag, _abstractNodes$attrib = abstractNodes.attributes, attributes = _abstractNodes$attrib === void 0 ? {} : _abstractNodes$attrib, _abstractNodes$childr = abstractNodes.children, children = _abstractNodes$childr === void 0 ? [] : _abstractNodes$childr;
  if (typeof abstractNodes === "string") {
    return htmlEscape(abstractNodes);
  } else {
    return "<".concat(tag, " ").concat(joinAttributes(attributes), ">").concat(children.map(toHtml).join(""), "</").concat(tag, ">");
  }
}
__name(toHtml, "toHtml");
function iconFromMapping(mapping, prefix, iconName) {
  if (mapping && mapping[prefix] && mapping[prefix][iconName]) {
    return {
      prefix,
      iconName,
      icon: mapping[prefix][iconName]
    };
  }
}
__name(iconFromMapping, "iconFromMapping");
var bindInternal4 = /* @__PURE__ */ __name(function bindInternal42(func, thisContext) {
  return function(a, b, c, d2) {
    return func.call(thisContext, a, b, c, d2);
  };
}, "bindInternal4");
var reduce = /* @__PURE__ */ __name(function fastReduceObject(subject, fn, initialValue, thisContext) {
  var keys = Object.keys(subject), length = keys.length, iterator = thisContext !== void 0 ? bindInternal4(fn, thisContext) : fn, i, key, result;
  if (initialValue === void 0) {
    i = 1;
    result = subject[keys[0]];
  } else {
    i = 0;
    result = initialValue;
  }
  for (; i < length; i++) {
    key = keys[i];
    result = iterator(result, subject[key], key, subject);
  }
  return result;
}, "fastReduceObject");
function ucs2decode(string) {
  var output = [];
  var counter = 0;
  var length = string.length;
  while (counter < length) {
    var value = string.charCodeAt(counter++);
    if (value >= 55296 && value <= 56319 && counter < length) {
      var extra = string.charCodeAt(counter++);
      if ((extra & 64512) == 56320) {
        output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
      } else {
        output.push(value);
        counter--;
      }
    } else {
      output.push(value);
    }
  }
  return output;
}
__name(ucs2decode, "ucs2decode");
function toHex(unicode) {
  var decoded = ucs2decode(unicode);
  return decoded.length === 1 ? decoded[0].toString(16) : null;
}
__name(toHex, "toHex");
function codePointAt(string, index) {
  var size = string.length;
  var first = string.charCodeAt(index);
  var second;
  if (first >= 55296 && first <= 56319 && size > index + 1) {
    second = string.charCodeAt(index + 1);
    if (second >= 56320 && second <= 57343) {
      return (first - 55296) * 1024 + second - 56320 + 65536;
    }
  }
  return first;
}
__name(codePointAt, "codePointAt");
function normalizeIcons(icons) {
  return Object.keys(icons).reduce(function(acc, iconName) {
    var icon2 = icons[iconName];
    var expanded = !!icon2.icon;
    if (expanded) {
      acc[icon2.iconName] = icon2.icon;
    } else {
      acc[iconName] = icon2;
    }
    return acc;
  }, {});
}
__name(normalizeIcons, "normalizeIcons");
function defineIcons(prefix, icons) {
  var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
  var _params$skipHooks = params.skipHooks, skipHooks = _params$skipHooks === void 0 ? false : _params$skipHooks;
  var normalized = normalizeIcons(icons);
  if (typeof namespace.hooks.addPack === "function" && !skipHooks) {
    namespace.hooks.addPack(prefix, normalizeIcons(icons));
  } else {
    namespace.styles[prefix] = _objectSpread2(_objectSpread2({}, namespace.styles[prefix] || {}), normalized);
  }
  if (prefix === "fas") {
    defineIcons("fa", icons);
  }
}
__name(defineIcons, "defineIcons");
var _LONG_STYLE, _PREFIXES, _PREFIXES_FOR_FAMILY;
var styles = namespace.styles, shims = namespace.shims;
var LONG_STYLE = (_LONG_STYLE = {}, _defineProperty(_LONG_STYLE, FAMILY_CLASSIC, Object.values(PREFIX_TO_LONG_STYLE[FAMILY_CLASSIC])), _defineProperty(_LONG_STYLE, FAMILY_SHARP, Object.values(PREFIX_TO_LONG_STYLE[FAMILY_SHARP])), _LONG_STYLE);
var _defaultUsablePrefix = null;
var _byUnicode = {};
var _byLigature = {};
var _byOldName = {};
var _byOldUnicode = {};
var _byAlias = {};
var PREFIXES = (_PREFIXES = {}, _defineProperty(_PREFIXES, FAMILY_CLASSIC, Object.keys(PREFIX_TO_STYLE[FAMILY_CLASSIC])), _defineProperty(_PREFIXES, FAMILY_SHARP, Object.keys(PREFIX_TO_STYLE[FAMILY_SHARP])), _PREFIXES);
function isReserved(name) {
  return ~RESERVED_CLASSES.indexOf(name);
}
__name(isReserved, "isReserved");
function getIconName(cssPrefix, cls) {
  var parts = cls.split("-");
  var prefix = parts[0];
  var iconName = parts.slice(1).join("-");
  if (prefix === cssPrefix && iconName !== "" && !isReserved(iconName)) {
    return iconName;
  } else {
    return null;
  }
}
__name(getIconName, "getIconName");
var build = /* @__PURE__ */ __name(function build2() {
  var lookup = /* @__PURE__ */ __name(function lookup2(reducer) {
    return reduce(styles, function(o, style, prefix) {
      o[prefix] = reduce(style, reducer, {});
      return o;
    }, {});
  }, "lookup");
  _byUnicode = lookup(function(acc, icon2, iconName) {
    if (icon2[3]) {
      acc[icon2[3]] = iconName;
    }
    if (icon2[2]) {
      var aliases = icon2[2].filter(function(a) {
        return typeof a === "number";
      });
      aliases.forEach(function(alias) {
        acc[alias.toString(16)] = iconName;
      });
    }
    return acc;
  });
  _byLigature = lookup(function(acc, icon2, iconName) {
    acc[iconName] = iconName;
    if (icon2[2]) {
      var aliases = icon2[2].filter(function(a) {
        return typeof a === "string";
      });
      aliases.forEach(function(alias) {
        acc[alias] = iconName;
      });
    }
    return acc;
  });
  _byAlias = lookup(function(acc, icon2, iconName) {
    var aliases = icon2[2];
    acc[iconName] = iconName;
    aliases.forEach(function(alias) {
      acc[alias] = iconName;
    });
    return acc;
  });
  var hasRegular = "far" in styles || config.autoFetchSvg;
  var shimLookups = reduce(shims, function(acc, shim) {
    var maybeNameMaybeUnicode = shim[0];
    var prefix = shim[1];
    var iconName = shim[2];
    if (prefix === "far" && !hasRegular) {
      prefix = "fas";
    }
    if (typeof maybeNameMaybeUnicode === "string") {
      acc.names[maybeNameMaybeUnicode] = {
        prefix,
        iconName
      };
    }
    if (typeof maybeNameMaybeUnicode === "number") {
      acc.unicodes[maybeNameMaybeUnicode.toString(16)] = {
        prefix,
        iconName
      };
    }
    return acc;
  }, {
    names: {},
    unicodes: {}
  });
  _byOldName = shimLookups.names;
  _byOldUnicode = shimLookups.unicodes;
  _defaultUsablePrefix = getCanonicalPrefix(config.styleDefault, {
    family: config.familyDefault
  });
}, "build");
onChange(function(c) {
  _defaultUsablePrefix = getCanonicalPrefix(c.styleDefault, {
    family: config.familyDefault
  });
});
build();
function byUnicode(prefix, unicode) {
  return (_byUnicode[prefix] || {})[unicode];
}
__name(byUnicode, "byUnicode");
function byLigature(prefix, ligature) {
  return (_byLigature[prefix] || {})[ligature];
}
__name(byLigature, "byLigature");
function byAlias(prefix, alias) {
  return (_byAlias[prefix] || {})[alias];
}
__name(byAlias, "byAlias");
function byOldName(name) {
  return _byOldName[name] || {
    prefix: null,
    iconName: null
  };
}
__name(byOldName, "byOldName");
function byOldUnicode(unicode) {
  var oldUnicode = _byOldUnicode[unicode];
  var newUnicode = byUnicode("fas", unicode);
  return oldUnicode || (newUnicode ? {
    prefix: "fas",
    iconName: newUnicode
  } : null) || {
    prefix: null,
    iconName: null
  };
}
__name(byOldUnicode, "byOldUnicode");
function getDefaultUsablePrefix() {
  return _defaultUsablePrefix;
}
__name(getDefaultUsablePrefix, "getDefaultUsablePrefix");
var emptyCanonicalIcon = /* @__PURE__ */ __name(function emptyCanonicalIcon2() {
  return {
    prefix: null,
    iconName: null,
    rest: []
  };
}, "emptyCanonicalIcon");
function getCanonicalPrefix(styleOrPrefix) {
  var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  var _params$family = params.family, family = _params$family === void 0 ? FAMILY_CLASSIC : _params$family;
  var style = PREFIX_TO_STYLE[family][styleOrPrefix];
  var prefix = STYLE_TO_PREFIX[family][styleOrPrefix] || STYLE_TO_PREFIX[family][style];
  var defined = styleOrPrefix in namespace.styles ? styleOrPrefix : null;
  return prefix || defined || null;
}
__name(getCanonicalPrefix, "getCanonicalPrefix");
var PREFIXES_FOR_FAMILY = (_PREFIXES_FOR_FAMILY = {}, _defineProperty(_PREFIXES_FOR_FAMILY, FAMILY_CLASSIC, Object.keys(PREFIX_TO_LONG_STYLE[FAMILY_CLASSIC])), _defineProperty(_PREFIXES_FOR_FAMILY, FAMILY_SHARP, Object.keys(PREFIX_TO_LONG_STYLE[FAMILY_SHARP])), _PREFIXES_FOR_FAMILY);
function getCanonicalIcon(values) {
  var _famProps;
  var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  var _params$skipLookups = params.skipLookups, skipLookups = _params$skipLookups === void 0 ? false : _params$skipLookups;
  var famProps = (_famProps = {}, _defineProperty(_famProps, FAMILY_CLASSIC, "".concat(config.cssPrefix, "-").concat(FAMILY_CLASSIC)), _defineProperty(_famProps, FAMILY_SHARP, "".concat(config.cssPrefix, "-").concat(FAMILY_SHARP)), _famProps);
  var givenPrefix = null;
  var family = FAMILY_CLASSIC;
  if (values.includes(famProps[FAMILY_CLASSIC]) || values.some(function(v) {
    return PREFIXES_FOR_FAMILY[FAMILY_CLASSIC].includes(v);
  })) {
    family = FAMILY_CLASSIC;
  }
  if (values.includes(famProps[FAMILY_SHARP]) || values.some(function(v) {
    return PREFIXES_FOR_FAMILY[FAMILY_SHARP].includes(v);
  })) {
    family = FAMILY_SHARP;
  }
  var canonical = values.reduce(function(acc, cls) {
    var iconName = getIconName(config.cssPrefix, cls);
    if (styles[cls]) {
      cls = LONG_STYLE[family].includes(cls) ? LONG_STYLE_TO_PREFIX[family][cls] : cls;
      givenPrefix = cls;
      acc.prefix = cls;
    } else if (PREFIXES[family].indexOf(cls) > -1) {
      givenPrefix = cls;
      acc.prefix = getCanonicalPrefix(cls, {
        family
      });
    } else if (iconName) {
      acc.iconName = iconName;
    } else if (cls !== config.replacementClass && cls !== famProps[FAMILY_CLASSIC] && cls !== famProps[FAMILY_SHARP]) {
      acc.rest.push(cls);
    }
    if (!skipLookups && acc.prefix && acc.iconName) {
      var shim = givenPrefix === "fa" ? byOldName(acc.iconName) : {};
      var aliasIconName = byAlias(acc.prefix, acc.iconName);
      if (shim.prefix) {
        givenPrefix = null;
      }
      acc.iconName = shim.iconName || aliasIconName || acc.iconName;
      acc.prefix = shim.prefix || acc.prefix;
      if (acc.prefix === "far" && !styles["far"] && styles["fas"] && !config.autoFetchSvg) {
        acc.prefix = "fas";
      }
    }
    return acc;
  }, emptyCanonicalIcon());
  if (values.includes("fa-brands") || values.includes("fab")) {
    canonical.prefix = "fab";
  }
  if (values.includes("fa-duotone") || values.includes("fad")) {
    canonical.prefix = "fad";
  }
  if (!canonical.prefix && family === FAMILY_SHARP && (styles["fass"] || config.autoFetchSvg)) {
    canonical.prefix = "fass";
    canonical.iconName = byAlias(canonical.prefix, canonical.iconName) || canonical.iconName;
  }
  if (canonical.prefix === "fa" || givenPrefix === "fa") {
    canonical.prefix = getDefaultUsablePrefix() || "fas";
  }
  return canonical;
}
__name(getCanonicalIcon, "getCanonicalIcon");
var Library = /* @__PURE__ */ function() {
  function Library2() {
    _classCallCheck(this, Library2);
    this.definitions = {};
  }
  __name(Library2, "Library");
  _createClass(Library2, [{
    key: "add",
    value: /* @__PURE__ */ __name(function add() {
      var _this = this;
      for (var _len = arguments.length, definitions = new Array(_len), _key = 0; _key < _len; _key++) {
        definitions[_key] = arguments[_key];
      }
      var additions = definitions.reduce(this._pullDefinitions, {});
      Object.keys(additions).forEach(function(key) {
        _this.definitions[key] = _objectSpread2(_objectSpread2({}, _this.definitions[key] || {}), additions[key]);
        defineIcons(key, additions[key]);
        var longPrefix = PREFIX_TO_LONG_STYLE[FAMILY_CLASSIC][key];
        if (longPrefix)
          defineIcons(longPrefix, additions[key]);
        build();
      });
    }, "add")
  }, {
    key: "reset",
    value: /* @__PURE__ */ __name(function reset() {
      this.definitions = {};
    }, "reset")
  }, {
    key: "_pullDefinitions",
    value: /* @__PURE__ */ __name(function _pullDefinitions(additions, definition) {
      var normalized = definition.prefix && definition.iconName && definition.icon ? {
        0: definition
      } : definition;
      Object.keys(normalized).map(function(key) {
        var _normalized$key = normalized[key], prefix = _normalized$key.prefix, iconName = _normalized$key.iconName, icon2 = _normalized$key.icon;
        var aliases = icon2[2];
        if (!additions[prefix])
          additions[prefix] = {};
        if (aliases.length > 0) {
          aliases.forEach(function(alias) {
            if (typeof alias === "string") {
              additions[prefix][alias] = icon2;
            }
          });
        }
        additions[prefix][iconName] = icon2;
      });
      return additions;
    }, "_pullDefinitions")
  }]);
  return Library2;
}();
var _plugins = [];
var _hooks = {};
var providers = {};
var defaultProviderKeys = Object.keys(providers);
function registerPlugins(nextPlugins, _ref2) {
  var obj = _ref2.mixoutsTo;
  _plugins = nextPlugins;
  _hooks = {};
  Object.keys(providers).forEach(function(k) {
    if (defaultProviderKeys.indexOf(k) === -1) {
      delete providers[k];
    }
  });
  _plugins.forEach(function(plugin) {
    var mixout8 = plugin.mixout ? plugin.mixout() : {};
    Object.keys(mixout8).forEach(function(tk) {
      if (typeof mixout8[tk] === "function") {
        obj[tk] = mixout8[tk];
      }
      if (_typeof(mixout8[tk]) === "object") {
        Object.keys(mixout8[tk]).forEach(function(sk) {
          if (!obj[tk]) {
            obj[tk] = {};
          }
          obj[tk][sk] = mixout8[tk][sk];
        });
      }
    });
    if (plugin.hooks) {
      var hooks8 = plugin.hooks();
      Object.keys(hooks8).forEach(function(hook) {
        if (!_hooks[hook]) {
          _hooks[hook] = [];
        }
        _hooks[hook].push(hooks8[hook]);
      });
    }
    if (plugin.provides) {
      plugin.provides(providers);
    }
  });
  return obj;
}
__name(registerPlugins, "registerPlugins");
function chainHooks(hook, accumulator) {
  for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
    args[_key - 2] = arguments[_key];
  }
  var hookFns = _hooks[hook] || [];
  hookFns.forEach(function(hookFn) {
    accumulator = hookFn.apply(null, [accumulator].concat(args));
  });
  return accumulator;
}
__name(chainHooks, "chainHooks");
function callHooks(hook) {
  for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
    args[_key2 - 1] = arguments[_key2];
  }
  var hookFns = _hooks[hook] || [];
  hookFns.forEach(function(hookFn) {
    hookFn.apply(null, args);
  });
  return void 0;
}
__name(callHooks, "callHooks");
function callProvided() {
  var hook = arguments[0];
  var args = Array.prototype.slice.call(arguments, 1);
  return providers[hook] ? providers[hook].apply(null, args) : void 0;
}
__name(callProvided, "callProvided");
function findIconDefinition(iconLookup) {
  if (iconLookup.prefix === "fa") {
    iconLookup.prefix = "fas";
  }
  var iconName = iconLookup.iconName;
  var prefix = iconLookup.prefix || getDefaultUsablePrefix();
  if (!iconName)
    return;
  iconName = byAlias(prefix, iconName) || iconName;
  return iconFromMapping(library.definitions, prefix, iconName) || iconFromMapping(namespace.styles, prefix, iconName);
}
__name(findIconDefinition, "findIconDefinition");
var library = new Library();
var noAuto = /* @__PURE__ */ __name(function noAuto2() {
  config.autoReplaceSvg = false;
  config.observeMutations = false;
  callHooks("noAuto");
}, "noAuto");
var dom = {
  i2svg: /* @__PURE__ */ __name(function i2svg() {
    var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (IS_DOM) {
      callHooks("beforeI2svg", params);
      callProvided("pseudoElements2svg", params);
      return callProvided("i2svg", params);
    } else {
      return Promise.reject("Operation requires a DOM of some kind.");
    }
  }, "i2svg"),
  watch: /* @__PURE__ */ __name(function watch() {
    var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    var autoReplaceSvgRoot = params.autoReplaceSvgRoot;
    if (config.autoReplaceSvg === false) {
      config.autoReplaceSvg = true;
    }
    config.observeMutations = true;
    domready(function() {
      autoReplace({
        autoReplaceSvgRoot
      });
      callHooks("watch", params);
    });
  }, "watch")
};
var parse = {
  icon: /* @__PURE__ */ __name(function icon(_icon) {
    if (_icon === null) {
      return null;
    }
    if (_typeof(_icon) === "object" && _icon.prefix && _icon.iconName) {
      return {
        prefix: _icon.prefix,
        iconName: byAlias(_icon.prefix, _icon.iconName) || _icon.iconName
      };
    }
    if (Array.isArray(_icon) && _icon.length === 2) {
      var iconName = _icon[1].indexOf("fa-") === 0 ? _icon[1].slice(3) : _icon[1];
      var prefix = getCanonicalPrefix(_icon[0]);
      return {
        prefix,
        iconName: byAlias(prefix, iconName) || iconName
      };
    }
    if (typeof _icon === "string" && (_icon.indexOf("".concat(config.cssPrefix, "-")) > -1 || _icon.match(ICON_SELECTION_SYNTAX_PATTERN))) {
      var canonicalIcon = getCanonicalIcon(_icon.split(" "), {
        skipLookups: true
      });
      return {
        prefix: canonicalIcon.prefix || getDefaultUsablePrefix(),
        iconName: byAlias(canonicalIcon.prefix, canonicalIcon.iconName) || canonicalIcon.iconName
      };
    }
    if (typeof _icon === "string") {
      var _prefix = getDefaultUsablePrefix();
      return {
        prefix: _prefix,
        iconName: byAlias(_prefix, _icon) || _icon
      };
    }
  }, "icon")
};
var api = {
  noAuto,
  config,
  dom,
  parse,
  library,
  findIconDefinition,
  toHtml
};
var autoReplace = /* @__PURE__ */ __name(function autoReplace2() {
  var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
  var _params$autoReplaceSv = params.autoReplaceSvgRoot, autoReplaceSvgRoot = _params$autoReplaceSv === void 0 ? DOCUMENT : _params$autoReplaceSv;
  if ((Object.keys(namespace.styles).length > 0 || config.autoFetchSvg) && IS_DOM && config.autoReplaceSvg)
    api.dom.i2svg({
      node: autoReplaceSvgRoot
    });
}, "autoReplace");
function domVariants(val, abstractCreator) {
  Object.defineProperty(val, "abstract", {
    get: abstractCreator
  });
  Object.defineProperty(val, "html", {
    get: /* @__PURE__ */ __name(function get2() {
      return val.abstract.map(function(a) {
        return toHtml(a);
      });
    }, "get")
  });
  Object.defineProperty(val, "node", {
    get: /* @__PURE__ */ __name(function get2() {
      if (!IS_DOM)
        return;
      var container = DOCUMENT.createElement("div");
      container.innerHTML = val.html;
      return container.children;
    }, "get")
  });
  return val;
}
__name(domVariants, "domVariants");
function asIcon(_ref2) {
  var children = _ref2.children, main = _ref2.main, mask = _ref2.mask, attributes = _ref2.attributes, styles2 = _ref2.styles, transform = _ref2.transform;
  if (transformIsMeaningful(transform) && main.found && !mask.found) {
    var width = main.width, height = main.height;
    var offset = {
      x: width / height / 2,
      y: 0.5
    };
    attributes["style"] = joinStyles(_objectSpread2(_objectSpread2({}, styles2), {}, {
      "transform-origin": "".concat(offset.x + transform.x / 16, "em ").concat(offset.y + transform.y / 16, "em")
    }));
  }
  return [{
    tag: "svg",
    attributes,
    children
  }];
}
__name(asIcon, "asIcon");
function asSymbol(_ref2) {
  var prefix = _ref2.prefix, iconName = _ref2.iconName, children = _ref2.children, attributes = _ref2.attributes, symbol = _ref2.symbol;
  var id = symbol === true ? "".concat(prefix, "-").concat(config.cssPrefix, "-").concat(iconName) : symbol;
  return [{
    tag: "svg",
    attributes: {
      style: "display: none;"
    },
    children: [{
      tag: "symbol",
      attributes: _objectSpread2(_objectSpread2({}, attributes), {}, {
        id
      }),
      children
    }]
  }];
}
__name(asSymbol, "asSymbol");
function makeInlineSvgAbstract(params) {
  var _params$icons = params.icons, main = _params$icons.main, mask = _params$icons.mask, prefix = params.prefix, iconName = params.iconName, transform = params.transform, symbol = params.symbol, title = params.title, maskId = params.maskId, titleId = params.titleId, extra = params.extra, _params$watchable = params.watchable, watchable = _params$watchable === void 0 ? false : _params$watchable;
  var _ref2 = mask.found ? mask : main, width = _ref2.width, height = _ref2.height;
  var isUploadedIcon = prefix === "fak";
  var attrClass = [config.replacementClass, iconName ? "".concat(config.cssPrefix, "-").concat(iconName) : ""].filter(function(c) {
    return extra.classes.indexOf(c) === -1;
  }).filter(function(c) {
    return c !== "" || !!c;
  }).concat(extra.classes).join(" ");
  var content = {
    children: [],
    attributes: _objectSpread2(_objectSpread2({}, extra.attributes), {}, {
      "data-prefix": prefix,
      "data-icon": iconName,
      "class": attrClass,
      "role": extra.attributes.role || "img",
      "xmlns": "http://www.w3.org/2000/svg",
      "viewBox": "0 0 ".concat(width, " ").concat(height)
    })
  };
  var uploadedIconWidthStyle = isUploadedIcon && !~extra.classes.indexOf("fa-fw") ? {
    width: "".concat(width / height * 16 * 0.0625, "em")
  } : {};
  if (watchable) {
    content.attributes[DATA_FA_I2SVG] = "";
  }
  if (title) {
    content.children.push({
      tag: "title",
      attributes: {
        id: content.attributes["aria-labelledby"] || "title-".concat(titleId || nextUniqueId())
      },
      children: [title]
    });
    delete content.attributes.title;
  }
  var args = _objectSpread2(_objectSpread2({}, content), {}, {
    prefix,
    iconName,
    main,
    mask,
    maskId,
    transform,
    symbol,
    styles: _objectSpread2(_objectSpread2({}, uploadedIconWidthStyle), extra.styles)
  });
  var _ref22 = mask.found && main.found ? callProvided("generateAbstractMask", args) || {
    children: [],
    attributes: {}
  } : callProvided("generateAbstractIcon", args) || {
    children: [],
    attributes: {}
  }, children = _ref22.children, attributes = _ref22.attributes;
  args.children = children;
  args.attributes = attributes;
  if (symbol) {
    return asSymbol(args);
  } else {
    return asIcon(args);
  }
}
__name(makeInlineSvgAbstract, "makeInlineSvgAbstract");
function makeLayersTextAbstract(params) {
  var content = params.content, width = params.width, height = params.height, transform = params.transform, title = params.title, extra = params.extra, _params$watchable2 = params.watchable, watchable = _params$watchable2 === void 0 ? false : _params$watchable2;
  var attributes = _objectSpread2(_objectSpread2(_objectSpread2({}, extra.attributes), title ? {
    "title": title
  } : {}), {}, {
    "class": extra.classes.join(" ")
  });
  if (watchable) {
    attributes[DATA_FA_I2SVG] = "";
  }
  var styles2 = _objectSpread2({}, extra.styles);
  if (transformIsMeaningful(transform)) {
    styles2["transform"] = transformForCss({
      transform,
      startCentered: true,
      width,
      height
    });
    styles2["-webkit-transform"] = styles2["transform"];
  }
  var styleString = joinStyles(styles2);
  if (styleString.length > 0) {
    attributes["style"] = styleString;
  }
  var val = [];
  val.push({
    tag: "span",
    attributes,
    children: [content]
  });
  if (title) {
    val.push({
      tag: "span",
      attributes: {
        class: "sr-only"
      },
      children: [title]
    });
  }
  return val;
}
__name(makeLayersTextAbstract, "makeLayersTextAbstract");
function makeLayersCounterAbstract(params) {
  var content = params.content, title = params.title, extra = params.extra;
  var attributes = _objectSpread2(_objectSpread2(_objectSpread2({}, extra.attributes), title ? {
    "title": title
  } : {}), {}, {
    "class": extra.classes.join(" ")
  });
  var styleString = joinStyles(extra.styles);
  if (styleString.length > 0) {
    attributes["style"] = styleString;
  }
  var val = [];
  val.push({
    tag: "span",
    attributes,
    children: [content]
  });
  if (title) {
    val.push({
      tag: "span",
      attributes: {
        class: "sr-only"
      },
      children: [title]
    });
  }
  return val;
}
__name(makeLayersCounterAbstract, "makeLayersCounterAbstract");
var styles$1 = namespace.styles;
function asFoundIcon(icon2) {
  var width = icon2[0];
  var height = icon2[1];
  var _icon$slice = icon2.slice(4), _icon$slice2 = _slicedToArray(_icon$slice, 1), vectorData = _icon$slice2[0];
  var element = null;
  if (Array.isArray(vectorData)) {
    element = {
      tag: "g",
      attributes: {
        class: "".concat(config.cssPrefix, "-").concat(DUOTONE_CLASSES.GROUP)
      },
      children: [{
        tag: "path",
        attributes: {
          class: "".concat(config.cssPrefix, "-").concat(DUOTONE_CLASSES.SECONDARY),
          fill: "currentColor",
          d: vectorData[0]
        }
      }, {
        tag: "path",
        attributes: {
          class: "".concat(config.cssPrefix, "-").concat(DUOTONE_CLASSES.PRIMARY),
          fill: "currentColor",
          d: vectorData[1]
        }
      }]
    };
  } else {
    element = {
      tag: "path",
      attributes: {
        fill: "currentColor",
        d: vectorData
      }
    };
  }
  return {
    found: true,
    width,
    height,
    icon: element
  };
}
__name(asFoundIcon, "asFoundIcon");
var missingIconResolutionMixin = {
  found: false,
  width: 512,
  height: 512
};
function maybeNotifyMissing(iconName, prefix) {
  if (!PRODUCTION && !config.showMissingIcons && iconName) {
    console.error('Icon with name "'.concat(iconName, '" and prefix "').concat(prefix, '" is missing.'));
  }
}
__name(maybeNotifyMissing, "maybeNotifyMissing");
function findIcon(iconName, prefix) {
  var givenPrefix = prefix;
  if (prefix === "fa" && config.styleDefault !== null) {
    prefix = getDefaultUsablePrefix();
  }
  return new Promise(function(resolve, reject) {
    ({
      found: false,
      width: 512,
      height: 512,
      icon: callProvided("missingIconAbstract") || {}
    });
    if (givenPrefix === "fa") {
      var shim = byOldName(iconName) || {};
      iconName = shim.iconName || iconName;
      prefix = shim.prefix || prefix;
    }
    if (iconName && prefix && styles$1[prefix] && styles$1[prefix][iconName]) {
      var icon2 = styles$1[prefix][iconName];
      return resolve(asFoundIcon(icon2));
    }
    maybeNotifyMissing(iconName, prefix);
    resolve(_objectSpread2(_objectSpread2({}, missingIconResolutionMixin), {}, {
      icon: config.showMissingIcons && iconName ? callProvided("missingIconAbstract") || {} : {}
    }));
  });
}
__name(findIcon, "findIcon");
var noop$1 = /* @__PURE__ */ __name(function noop3() {
}, "noop");
var p = config.measurePerformance && PERFORMANCE && PERFORMANCE.mark && PERFORMANCE.measure ? PERFORMANCE : {
  mark: noop$1,
  measure: noop$1
};
var preamble = 'FA "6.5.2"';
var begin = /* @__PURE__ */ __name(function begin2(name) {
  p.mark("".concat(preamble, " ").concat(name, " begins"));
  return function() {
    return end(name);
  };
}, "begin");
var end = /* @__PURE__ */ __name(function end2(name) {
  p.mark("".concat(preamble, " ").concat(name, " ends"));
  p.measure("".concat(preamble, " ").concat(name), "".concat(preamble, " ").concat(name, " begins"), "".concat(preamble, " ").concat(name, " ends"));
}, "end");
var perf = {
  begin,
  end
};
var noop$2 = /* @__PURE__ */ __name(function noop4() {
}, "noop");
function isWatched(node) {
  var i2svg2 = node.getAttribute ? node.getAttribute(DATA_FA_I2SVG) : null;
  return typeof i2svg2 === "string";
}
__name(isWatched, "isWatched");
function hasPrefixAndIcon(node) {
  var prefix = node.getAttribute ? node.getAttribute(DATA_PREFIX) : null;
  var icon2 = node.getAttribute ? node.getAttribute(DATA_ICON) : null;
  return prefix && icon2;
}
__name(hasPrefixAndIcon, "hasPrefixAndIcon");
function hasBeenReplaced(node) {
  return node && node.classList && node.classList.contains && node.classList.contains(config.replacementClass);
}
__name(hasBeenReplaced, "hasBeenReplaced");
function getMutator() {
  if (config.autoReplaceSvg === true) {
    return mutators.replace;
  }
  var mutator = mutators[config.autoReplaceSvg];
  return mutator || mutators.replace;
}
__name(getMutator, "getMutator");
function createElementNS(tag) {
  return DOCUMENT.createElementNS("http://www.w3.org/2000/svg", tag);
}
__name(createElementNS, "createElementNS");
function createElement(tag) {
  return DOCUMENT.createElement(tag);
}
__name(createElement, "createElement");
function convertSVG(abstractObj) {
  var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  var _params$ceFn = params.ceFn, ceFn = _params$ceFn === void 0 ? abstractObj.tag === "svg" ? createElementNS : createElement : _params$ceFn;
  if (typeof abstractObj === "string") {
    return DOCUMENT.createTextNode(abstractObj);
  }
  var tag = ceFn(abstractObj.tag);
  Object.keys(abstractObj.attributes || []).forEach(function(key) {
    tag.setAttribute(key, abstractObj.attributes[key]);
  });
  var children = abstractObj.children || [];
  children.forEach(function(child) {
    tag.appendChild(convertSVG(child, {
      ceFn
    }));
  });
  return tag;
}
__name(convertSVG, "convertSVG");
function nodeAsComment(node) {
  var comment = " ".concat(node.outerHTML, " ");
  comment = "".concat(comment, "Font Awesome fontawesome.com ");
  return comment;
}
__name(nodeAsComment, "nodeAsComment");
var mutators = {
  replace: /* @__PURE__ */ __name(function replace(mutation) {
    var node = mutation[0];
    if (node.parentNode) {
      mutation[1].forEach(function(_abstract) {
        node.parentNode.insertBefore(convertSVG(_abstract), node);
      });
      if (node.getAttribute(DATA_FA_I2SVG) === null && config.keepOriginalSource) {
        var comment = DOCUMENT.createComment(nodeAsComment(node));
        node.parentNode.replaceChild(comment, node);
      } else {
        node.remove();
      }
    }
  }, "replace"),
  nest: /* @__PURE__ */ __name(function nest(mutation) {
    var node = mutation[0];
    var _abstract2 = mutation[1];
    if (~classArray(node).indexOf(config.replacementClass)) {
      return mutators.replace(mutation);
    }
    var forSvg = new RegExp("".concat(config.cssPrefix, "-.*"));
    delete _abstract2[0].attributes.id;
    if (_abstract2[0].attributes.class) {
      var splitClasses = _abstract2[0].attributes.class.split(" ").reduce(function(acc, cls) {
        if (cls === config.replacementClass || cls.match(forSvg)) {
          acc.toSvg.push(cls);
        } else {
          acc.toNode.push(cls);
        }
        return acc;
      }, {
        toNode: [],
        toSvg: []
      });
      _abstract2[0].attributes.class = splitClasses.toSvg.join(" ");
      if (splitClasses.toNode.length === 0) {
        node.removeAttribute("class");
      } else {
        node.setAttribute("class", splitClasses.toNode.join(" "));
      }
    }
    var newInnerHTML = _abstract2.map(function(a) {
      return toHtml(a);
    }).join("\n");
    node.setAttribute(DATA_FA_I2SVG, "");
    node.innerHTML = newInnerHTML;
  }, "nest")
};
function performOperationSync(op) {
  op();
}
__name(performOperationSync, "performOperationSync");
function perform(mutations, callback) {
  var callbackFunction = typeof callback === "function" ? callback : noop$2;
  if (mutations.length === 0) {
    callbackFunction();
  } else {
    var frame = performOperationSync;
    if (config.mutateApproach === MUTATION_APPROACH_ASYNC) {
      frame = WINDOW.requestAnimationFrame || performOperationSync;
    }
    frame(function() {
      var mutator = getMutator();
      var mark = perf.begin("mutate");
      mutations.map(mutator);
      mark();
      callbackFunction();
    });
  }
}
__name(perform, "perform");
var disabled = false;
function disableObservation() {
  disabled = true;
}
__name(disableObservation, "disableObservation");
function enableObservation() {
  disabled = false;
}
__name(enableObservation, "enableObservation");
var mo = null;
function observe(options) {
  if (!MUTATION_OBSERVER) {
    return;
  }
  if (!config.observeMutations) {
    return;
  }
  var _options$treeCallback = options.treeCallback, treeCallback = _options$treeCallback === void 0 ? noop$2 : _options$treeCallback, _options$nodeCallback = options.nodeCallback, nodeCallback = _options$nodeCallback === void 0 ? noop$2 : _options$nodeCallback, _options$pseudoElemen = options.pseudoElementsCallback, pseudoElementsCallback = _options$pseudoElemen === void 0 ? noop$2 : _options$pseudoElemen, _options$observeMutat = options.observeMutationsRoot, observeMutationsRoot = _options$observeMutat === void 0 ? DOCUMENT : _options$observeMutat;
  mo = new MUTATION_OBSERVER(function(objects) {
    if (disabled)
      return;
    var defaultPrefix = getDefaultUsablePrefix();
    toArray(objects).forEach(function(mutationRecord) {
      if (mutationRecord.type === "childList" && mutationRecord.addedNodes.length > 0 && !isWatched(mutationRecord.addedNodes[0])) {
        if (config.searchPseudoElements) {
          pseudoElementsCallback(mutationRecord.target);
        }
        treeCallback(mutationRecord.target);
      }
      if (mutationRecord.type === "attributes" && mutationRecord.target.parentNode && config.searchPseudoElements) {
        pseudoElementsCallback(mutationRecord.target.parentNode);
      }
      if (mutationRecord.type === "attributes" && isWatched(mutationRecord.target) && ~ATTRIBUTES_WATCHED_FOR_MUTATION.indexOf(mutationRecord.attributeName)) {
        if (mutationRecord.attributeName === "class" && hasPrefixAndIcon(mutationRecord.target)) {
          var _getCanonicalIcon = getCanonicalIcon(classArray(mutationRecord.target)), prefix = _getCanonicalIcon.prefix, iconName = _getCanonicalIcon.iconName;
          mutationRecord.target.setAttribute(DATA_PREFIX, prefix || defaultPrefix);
          if (iconName)
            mutationRecord.target.setAttribute(DATA_ICON, iconName);
        } else if (hasBeenReplaced(mutationRecord.target)) {
          nodeCallback(mutationRecord.target);
        }
      }
    });
  });
  if (!IS_DOM)
    return;
  mo.observe(observeMutationsRoot, {
    childList: true,
    attributes: true,
    characterData: true,
    subtree: true
  });
}
__name(observe, "observe");
function disconnect() {
  if (!mo)
    return;
  mo.disconnect();
}
__name(disconnect, "disconnect");
function styleParser(node) {
  var style = node.getAttribute("style");
  var val = [];
  if (style) {
    val = style.split(";").reduce(function(acc, style2) {
      var styles2 = style2.split(":");
      var prop = styles2[0];
      var value = styles2.slice(1);
      if (prop && value.length > 0) {
        acc[prop] = value.join(":").trim();
      }
      return acc;
    }, {});
  }
  return val;
}
__name(styleParser, "styleParser");
function classParser(node) {
  var existingPrefix = node.getAttribute("data-prefix");
  var existingIconName = node.getAttribute("data-icon");
  var innerText = node.innerText !== void 0 ? node.innerText.trim() : "";
  var val = getCanonicalIcon(classArray(node));
  if (!val.prefix) {
    val.prefix = getDefaultUsablePrefix();
  }
  if (existingPrefix && existingIconName) {
    val.prefix = existingPrefix;
    val.iconName = existingIconName;
  }
  if (val.iconName && val.prefix) {
    return val;
  }
  if (val.prefix && innerText.length > 0) {
    val.iconName = byLigature(val.prefix, node.innerText) || byUnicode(val.prefix, toHex(node.innerText));
  }
  if (!val.iconName && config.autoFetchSvg && node.firstChild && node.firstChild.nodeType === Node.TEXT_NODE) {
    val.iconName = node.firstChild.data;
  }
  return val;
}
__name(classParser, "classParser");
function attributesParser(node) {
  var extraAttributes = toArray(node.attributes).reduce(function(acc, attr) {
    if (acc.name !== "class" && acc.name !== "style") {
      acc[attr.name] = attr.value;
    }
    return acc;
  }, {});
  var title = node.getAttribute("title");
  var titleId = node.getAttribute("data-fa-title-id");
  if (config.autoA11y) {
    if (title) {
      extraAttributes["aria-labelledby"] = "".concat(config.replacementClass, "-title-").concat(titleId || nextUniqueId());
    } else {
      extraAttributes["aria-hidden"] = "true";
      extraAttributes["focusable"] = "false";
    }
  }
  return extraAttributes;
}
__name(attributesParser, "attributesParser");
function blankMeta() {
  return {
    iconName: null,
    title: null,
    titleId: null,
    prefix: null,
    transform: meaninglessTransform,
    symbol: false,
    mask: {
      iconName: null,
      prefix: null,
      rest: []
    },
    maskId: null,
    extra: {
      classes: [],
      styles: {},
      attributes: {}
    }
  };
}
__name(blankMeta, "blankMeta");
function parseMeta(node) {
  var parser = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
    styleParser: true
  };
  var _classParser = classParser(node), iconName = _classParser.iconName, prefix = _classParser.prefix, extraClasses = _classParser.rest;
  var extraAttributes = attributesParser(node);
  var pluginMeta = chainHooks("parseNodeAttributes", {}, node);
  var extraStyles = parser.styleParser ? styleParser(node) : [];
  return _objectSpread2({
    iconName,
    title: node.getAttribute("title"),
    titleId: node.getAttribute("data-fa-title-id"),
    prefix,
    transform: meaninglessTransform,
    mask: {
      iconName: null,
      prefix: null,
      rest: []
    },
    maskId: null,
    symbol: false,
    extra: {
      classes: extraClasses,
      styles: extraStyles,
      attributes: extraAttributes
    }
  }, pluginMeta);
}
__name(parseMeta, "parseMeta");
var styles$2 = namespace.styles;
function generateMutation(node) {
  var nodeMeta = config.autoReplaceSvg === "nest" ? parseMeta(node, {
    styleParser: false
  }) : parseMeta(node);
  if (~nodeMeta.extra.classes.indexOf(LAYERS_TEXT_CLASSNAME)) {
    return callProvided("generateLayersText", node, nodeMeta);
  } else {
    return callProvided("generateSvgReplacementMutation", node, nodeMeta);
  }
}
__name(generateMutation, "generateMutation");
var knownPrefixes = /* @__PURE__ */ new Set();
FAMILIES.map(function(family) {
  knownPrefixes.add("fa-".concat(family));
});
Object.keys(PREFIX_TO_STYLE[FAMILY_CLASSIC]).map(knownPrefixes.add.bind(knownPrefixes));
Object.keys(PREFIX_TO_STYLE[FAMILY_SHARP]).map(knownPrefixes.add.bind(knownPrefixes));
knownPrefixes = _toConsumableArray(knownPrefixes);
function onTree(root) {
  var callback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
  if (!IS_DOM)
    return Promise.resolve();
  var htmlClassList = DOCUMENT.documentElement.classList;
  var hclAdd = /* @__PURE__ */ __name(function hclAdd2(suffix) {
    return htmlClassList.add("".concat(HTML_CLASS_I2SVG_BASE_CLASS, "-").concat(suffix));
  }, "hclAdd");
  var hclRemove = /* @__PURE__ */ __name(function hclRemove2(suffix) {
    return htmlClassList.remove("".concat(HTML_CLASS_I2SVG_BASE_CLASS, "-").concat(suffix));
  }, "hclRemove");
  var prefixes2 = config.autoFetchSvg ? knownPrefixes : FAMILIES.map(function(f) {
    return "fa-".concat(f);
  }).concat(Object.keys(styles$2));
  if (!prefixes2.includes("fa")) {
    prefixes2.push("fa");
  }
  var prefixesDomQuery = [".".concat(LAYERS_TEXT_CLASSNAME, ":not([").concat(DATA_FA_I2SVG, "])")].concat(prefixes2.map(function(p2) {
    return ".".concat(p2, ":not([").concat(DATA_FA_I2SVG, "])");
  })).join(", ");
  if (prefixesDomQuery.length === 0) {
    return Promise.resolve();
  }
  var candidates = [];
  try {
    candidates = toArray(root.querySelectorAll(prefixesDomQuery));
  } catch (e) {
  }
  if (candidates.length > 0) {
    hclAdd("pending");
    hclRemove("complete");
  } else {
    return Promise.resolve();
  }
  var mark = perf.begin("onTree");
  var mutations = candidates.reduce(function(acc, node) {
    try {
      var mutation = generateMutation(node);
      if (mutation) {
        acc.push(mutation);
      }
    } catch (e) {
      if (!PRODUCTION) {
        if (e.name === "MissingIcon") {
          console.error(e);
        }
      }
    }
    return acc;
  }, []);
  return new Promise(function(resolve, reject) {
    Promise.all(mutations).then(function(resolvedMutations) {
      perform(resolvedMutations, function() {
        hclAdd("active");
        hclAdd("complete");
        hclRemove("pending");
        if (typeof callback === "function")
          callback();
        mark();
        resolve();
      });
    }).catch(function(e) {
      mark();
      reject(e);
    });
  });
}
__name(onTree, "onTree");
function onNode(node) {
  var callback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
  generateMutation(node).then(function(mutation) {
    if (mutation) {
      perform([mutation], callback);
    }
  });
}
__name(onNode, "onNode");
function resolveIcons(next) {
  return function(maybeIconDefinition) {
    var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var iconDefinition = (maybeIconDefinition || {}).icon ? maybeIconDefinition : findIconDefinition(maybeIconDefinition || {});
    var mask = params.mask;
    if (mask) {
      mask = (mask || {}).icon ? mask : findIconDefinition(mask || {});
    }
    return next(iconDefinition, _objectSpread2(_objectSpread2({}, params), {}, {
      mask
    }));
  };
}
__name(resolveIcons, "resolveIcons");
var render = /* @__PURE__ */ __name(function render2(iconDefinition) {
  var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  var _params$transform = params.transform, transform = _params$transform === void 0 ? meaninglessTransform : _params$transform, _params$symbol = params.symbol, symbol = _params$symbol === void 0 ? false : _params$symbol, _params$mask = params.mask, mask = _params$mask === void 0 ? null : _params$mask, _params$maskId = params.maskId, maskId = _params$maskId === void 0 ? null : _params$maskId, _params$title = params.title, title = _params$title === void 0 ? null : _params$title, _params$titleId = params.titleId, titleId = _params$titleId === void 0 ? null : _params$titleId, _params$classes = params.classes, classes = _params$classes === void 0 ? [] : _params$classes, _params$attributes = params.attributes, attributes = _params$attributes === void 0 ? {} : _params$attributes, _params$styles = params.styles, styles2 = _params$styles === void 0 ? {} : _params$styles;
  if (!iconDefinition)
    return;
  var prefix = iconDefinition.prefix, iconName = iconDefinition.iconName, icon2 = iconDefinition.icon;
  return domVariants(_objectSpread2({
    type: "icon"
  }, iconDefinition), function() {
    callHooks("beforeDOMElementCreation", {
      iconDefinition,
      params
    });
    if (config.autoA11y) {
      if (title) {
        attributes["aria-labelledby"] = "".concat(config.replacementClass, "-title-").concat(titleId || nextUniqueId());
      } else {
        attributes["aria-hidden"] = "true";
        attributes["focusable"] = "false";
      }
    }
    return makeInlineSvgAbstract({
      icons: {
        main: asFoundIcon(icon2),
        mask: mask ? asFoundIcon(mask.icon) : {
          found: false,
          width: null,
          height: null,
          icon: {}
        }
      },
      prefix,
      iconName,
      transform: _objectSpread2(_objectSpread2({}, meaninglessTransform), transform),
      symbol,
      title,
      maskId,
      titleId,
      extra: {
        attributes,
        styles: styles2,
        classes
      }
    });
  });
}, "render");
var ReplaceElements = {
  mixout: /* @__PURE__ */ __name(function mixout2() {
    return {
      icon: resolveIcons(render)
    };
  }, "mixout"),
  hooks: /* @__PURE__ */ __name(function hooks2() {
    return {
      mutationObserverCallbacks: /* @__PURE__ */ __name(function mutationObserverCallbacks(accumulator) {
        accumulator.treeCallback = onTree;
        accumulator.nodeCallback = onNode;
        return accumulator;
      }, "mutationObserverCallbacks")
    };
  }, "hooks"),
  provides: /* @__PURE__ */ __name(function provides(providers$$1) {
    providers$$1.i2svg = function(params) {
      var _params$node = params.node, node = _params$node === void 0 ? DOCUMENT : _params$node, _params$callback = params.callback, callback = _params$callback === void 0 ? function() {
      } : _params$callback;
      return onTree(node, callback);
    };
    providers$$1.generateSvgReplacementMutation = function(node, nodeMeta) {
      var iconName = nodeMeta.iconName, title = nodeMeta.title, titleId = nodeMeta.titleId, prefix = nodeMeta.prefix, transform = nodeMeta.transform, symbol = nodeMeta.symbol, mask = nodeMeta.mask, maskId = nodeMeta.maskId, extra = nodeMeta.extra;
      return new Promise(function(resolve, reject) {
        Promise.all([findIcon(iconName, prefix), mask.iconName ? findIcon(mask.iconName, mask.prefix) : Promise.resolve({
          found: false,
          width: 512,
          height: 512,
          icon: {}
        })]).then(function(_ref2) {
          var _ref22 = _slicedToArray(_ref2, 2), main = _ref22[0], mask2 = _ref22[1];
          resolve([node, makeInlineSvgAbstract({
            icons: {
              main,
              mask: mask2
            },
            prefix,
            iconName,
            transform,
            symbol,
            maskId,
            title,
            titleId,
            extra,
            watchable: true
          })]);
        }).catch(reject);
      });
    };
    providers$$1.generateAbstractIcon = function(_ref3) {
      var children = _ref3.children, attributes = _ref3.attributes, main = _ref3.main, transform = _ref3.transform, styles2 = _ref3.styles;
      var styleString = joinStyles(styles2);
      if (styleString.length > 0) {
        attributes["style"] = styleString;
      }
      var nextChild;
      if (transformIsMeaningful(transform)) {
        nextChild = callProvided("generateAbstractTransformGrouping", {
          main,
          transform,
          containerWidth: main.width,
          iconWidth: main.width
        });
      }
      children.push(nextChild || main.icon);
      return {
        children,
        attributes
      };
    };
  }, "provides")
};
var Layers = {
  mixout: /* @__PURE__ */ __name(function mixout3() {
    return {
      layer: /* @__PURE__ */ __name(function layer(assembler) {
        var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        var _params$classes = params.classes, classes = _params$classes === void 0 ? [] : _params$classes;
        return domVariants({
          type: "layer"
        }, function() {
          callHooks("beforeDOMElementCreation", {
            assembler,
            params
          });
          var children = [];
          assembler(function(args) {
            Array.isArray(args) ? args.map(function(a) {
              children = children.concat(a.abstract);
            }) : children = children.concat(args.abstract);
          });
          return [{
            tag: "span",
            attributes: {
              class: ["".concat(config.cssPrefix, "-layers")].concat(_toConsumableArray(classes)).join(" ")
            },
            children
          }];
        });
      }, "layer")
    };
  }, "mixout")
};
var LayersCounter = {
  mixout: /* @__PURE__ */ __name(function mixout4() {
    return {
      counter: /* @__PURE__ */ __name(function counter(content) {
        var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        var _params$title = params.title, title = _params$title === void 0 ? null : _params$title, _params$classes = params.classes, classes = _params$classes === void 0 ? [] : _params$classes, _params$attributes = params.attributes, attributes = _params$attributes === void 0 ? {} : _params$attributes, _params$styles = params.styles, styles2 = _params$styles === void 0 ? {} : _params$styles;
        return domVariants({
          type: "counter",
          content
        }, function() {
          callHooks("beforeDOMElementCreation", {
            content,
            params
          });
          return makeLayersCounterAbstract({
            content: content.toString(),
            title,
            extra: {
              attributes,
              styles: styles2,
              classes: ["".concat(config.cssPrefix, "-layers-counter")].concat(_toConsumableArray(classes))
            }
          });
        });
      }, "counter")
    };
  }, "mixout")
};
var LayersText = {
  mixout: /* @__PURE__ */ __name(function mixout5() {
    return {
      text: /* @__PURE__ */ __name(function text(content) {
        var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        var _params$transform = params.transform, transform = _params$transform === void 0 ? meaninglessTransform : _params$transform, _params$title = params.title, title = _params$title === void 0 ? null : _params$title, _params$classes = params.classes, classes = _params$classes === void 0 ? [] : _params$classes, _params$attributes = params.attributes, attributes = _params$attributes === void 0 ? {} : _params$attributes, _params$styles = params.styles, styles2 = _params$styles === void 0 ? {} : _params$styles;
        return domVariants({
          type: "text",
          content
        }, function() {
          callHooks("beforeDOMElementCreation", {
            content,
            params
          });
          return makeLayersTextAbstract({
            content,
            transform: _objectSpread2(_objectSpread2({}, meaninglessTransform), transform),
            title,
            extra: {
              attributes,
              styles: styles2,
              classes: ["".concat(config.cssPrefix, "-layers-text")].concat(_toConsumableArray(classes))
            }
          });
        });
      }, "text")
    };
  }, "mixout"),
  provides: /* @__PURE__ */ __name(function provides2(providers$$1) {
    providers$$1.generateLayersText = function(node, nodeMeta) {
      var title = nodeMeta.title, transform = nodeMeta.transform, extra = nodeMeta.extra;
      var width = null;
      var height = null;
      if (IS_IE) {
        var computedFontSize = parseInt(getComputedStyle(node).fontSize, 10);
        var boundingClientRect = node.getBoundingClientRect();
        width = boundingClientRect.width / computedFontSize;
        height = boundingClientRect.height / computedFontSize;
      }
      if (config.autoA11y && !title) {
        extra.attributes["aria-hidden"] = "true";
      }
      return Promise.resolve([node, makeLayersTextAbstract({
        content: node.innerHTML,
        width,
        height,
        transform,
        title,
        extra,
        watchable: true
      })]);
    };
  }, "provides")
};
var CLEAN_CONTENT_PATTERN = new RegExp('"', "ug");
var SECONDARY_UNICODE_RANGE = [1105920, 1112319];
function hexValueFromContent(content) {
  var cleaned = content.replace(CLEAN_CONTENT_PATTERN, "");
  var codePoint = codePointAt(cleaned, 0);
  var isPrependTen = codePoint >= SECONDARY_UNICODE_RANGE[0] && codePoint <= SECONDARY_UNICODE_RANGE[1];
  var isDoubled = cleaned.length === 2 ? cleaned[0] === cleaned[1] : false;
  return {
    value: isDoubled ? toHex(cleaned[0]) : toHex(cleaned),
    isSecondary: isPrependTen || isDoubled
  };
}
__name(hexValueFromContent, "hexValueFromContent");
function replaceForPosition(node, position) {
  var pendingAttribute = "".concat(DATA_FA_PSEUDO_ELEMENT_PENDING).concat(position.replace(":", "-"));
  return new Promise(function(resolve, reject) {
    if (node.getAttribute(pendingAttribute) !== null) {
      return resolve();
    }
    var children = toArray(node.children);
    var alreadyProcessedPseudoElement = children.filter(function(c) {
      return c.getAttribute(DATA_FA_PSEUDO_ELEMENT) === position;
    })[0];
    var styles2 = WINDOW.getComputedStyle(node, position);
    var fontFamily = styles2.getPropertyValue("font-family").match(FONT_FAMILY_PATTERN);
    var fontWeight = styles2.getPropertyValue("font-weight");
    var content = styles2.getPropertyValue("content");
    if (alreadyProcessedPseudoElement && !fontFamily) {
      node.removeChild(alreadyProcessedPseudoElement);
      return resolve();
    } else if (fontFamily && content !== "none" && content !== "") {
      var _content = styles2.getPropertyValue("content");
      var family = ~["Sharp"].indexOf(fontFamily[2]) ? FAMILY_SHARP : FAMILY_CLASSIC;
      var prefix = ~["Solid", "Regular", "Light", "Thin", "Duotone", "Brands", "Kit"].indexOf(fontFamily[2]) ? STYLE_TO_PREFIX[family][fontFamily[2].toLowerCase()] : FONT_WEIGHT_TO_PREFIX[family][fontWeight];
      var _hexValueFromContent = hexValueFromContent(_content), hexValue = _hexValueFromContent.value, isSecondary = _hexValueFromContent.isSecondary;
      var isV4 = fontFamily[0].startsWith("FontAwesome");
      var iconName = byUnicode(prefix, hexValue);
      var iconIdentifier = iconName;
      if (isV4) {
        var iconName4 = byOldUnicode(hexValue);
        if (iconName4.iconName && iconName4.prefix) {
          iconName = iconName4.iconName;
          prefix = iconName4.prefix;
        }
      }
      if (iconName && !isSecondary && (!alreadyProcessedPseudoElement || alreadyProcessedPseudoElement.getAttribute(DATA_PREFIX) !== prefix || alreadyProcessedPseudoElement.getAttribute(DATA_ICON) !== iconIdentifier)) {
        node.setAttribute(pendingAttribute, iconIdentifier);
        if (alreadyProcessedPseudoElement) {
          node.removeChild(alreadyProcessedPseudoElement);
        }
        var meta = blankMeta();
        var extra = meta.extra;
        extra.attributes[DATA_FA_PSEUDO_ELEMENT] = position;
        findIcon(iconName, prefix).then(function(main) {
          var _abstract = makeInlineSvgAbstract(_objectSpread2(_objectSpread2({}, meta), {}, {
            icons: {
              main,
              mask: emptyCanonicalIcon()
            },
            prefix,
            iconName: iconIdentifier,
            extra,
            watchable: true
          }));
          var element = DOCUMENT.createElementNS("http://www.w3.org/2000/svg", "svg");
          if (position === "::before") {
            node.insertBefore(element, node.firstChild);
          } else {
            node.appendChild(element);
          }
          element.outerHTML = _abstract.map(function(a) {
            return toHtml(a);
          }).join("\n");
          node.removeAttribute(pendingAttribute);
          resolve();
        }).catch(reject);
      } else {
        resolve();
      }
    } else {
      resolve();
    }
  });
}
__name(replaceForPosition, "replaceForPosition");
function replace2(node) {
  return Promise.all([replaceForPosition(node, "::before"), replaceForPosition(node, "::after")]);
}
__name(replace2, "replace");
function processable(node) {
  return node.parentNode !== document.head && !~TAGNAMES_TO_SKIP_FOR_PSEUDOELEMENTS.indexOf(node.tagName.toUpperCase()) && !node.getAttribute(DATA_FA_PSEUDO_ELEMENT) && (!node.parentNode || node.parentNode.tagName !== "svg");
}
__name(processable, "processable");
function searchPseudoElements(root) {
  if (!IS_DOM)
    return;
  return new Promise(function(resolve, reject) {
    var operations = toArray(root.querySelectorAll("*")).filter(processable).map(replace2);
    var end3 = perf.begin("searchPseudoElements");
    disableObservation();
    Promise.all(operations).then(function() {
      end3();
      enableObservation();
      resolve();
    }).catch(function() {
      end3();
      enableObservation();
      reject();
    });
  });
}
__name(searchPseudoElements, "searchPseudoElements");
var PseudoElements = {
  hooks: /* @__PURE__ */ __name(function hooks3() {
    return {
      mutationObserverCallbacks: /* @__PURE__ */ __name(function mutationObserverCallbacks(accumulator) {
        accumulator.pseudoElementsCallback = searchPseudoElements;
        return accumulator;
      }, "mutationObserverCallbacks")
    };
  }, "hooks"),
  provides: /* @__PURE__ */ __name(function provides3(providers$$1) {
    providers$$1.pseudoElements2svg = function(params) {
      var _params$node = params.node, node = _params$node === void 0 ? DOCUMENT : _params$node;
      if (config.searchPseudoElements) {
        searchPseudoElements(node);
      }
    };
  }, "provides")
};
var _unwatched = false;
var MutationObserver$1 = {
  mixout: /* @__PURE__ */ __name(function mixout6() {
    return {
      dom: {
        unwatch: /* @__PURE__ */ __name(function unwatch() {
          disableObservation();
          _unwatched = true;
        }, "unwatch")
      }
    };
  }, "mixout"),
  hooks: /* @__PURE__ */ __name(function hooks4() {
    return {
      bootstrap: /* @__PURE__ */ __name(function bootstrap() {
        observe(chainHooks("mutationObserverCallbacks", {}));
      }, "bootstrap"),
      noAuto: /* @__PURE__ */ __name(function noAuto3() {
        disconnect();
      }, "noAuto"),
      watch: /* @__PURE__ */ __name(function watch2(params) {
        var observeMutationsRoot = params.observeMutationsRoot;
        if (_unwatched) {
          enableObservation();
        } else {
          observe(chainHooks("mutationObserverCallbacks", {
            observeMutationsRoot
          }));
        }
      }, "watch")
    };
  }, "hooks")
};
var parseTransformString = /* @__PURE__ */ __name(function parseTransformString2(transformString) {
  var transform = {
    size: 16,
    x: 0,
    y: 0,
    flipX: false,
    flipY: false,
    rotate: 0
  };
  return transformString.toLowerCase().split(" ").reduce(function(acc, n) {
    var parts = n.toLowerCase().split("-");
    var first = parts[0];
    var rest = parts.slice(1).join("-");
    if (first && rest === "h") {
      acc.flipX = true;
      return acc;
    }
    if (first && rest === "v") {
      acc.flipY = true;
      return acc;
    }
    rest = parseFloat(rest);
    if (isNaN(rest)) {
      return acc;
    }
    switch (first) {
      case "grow":
        acc.size = acc.size + rest;
        break;
      case "shrink":
        acc.size = acc.size - rest;
        break;
      case "left":
        acc.x = acc.x - rest;
        break;
      case "right":
        acc.x = acc.x + rest;
        break;
      case "up":
        acc.y = acc.y - rest;
        break;
      case "down":
        acc.y = acc.y + rest;
        break;
      case "rotate":
        acc.rotate = acc.rotate + rest;
        break;
    }
    return acc;
  }, transform);
}, "parseTransformString");
var PowerTransforms = {
  mixout: /* @__PURE__ */ __name(function mixout7() {
    return {
      parse: {
        transform: /* @__PURE__ */ __name(function transform(transformString) {
          return parseTransformString(transformString);
        }, "transform")
      }
    };
  }, "mixout"),
  hooks: /* @__PURE__ */ __name(function hooks5() {
    return {
      parseNodeAttributes: /* @__PURE__ */ __name(function parseNodeAttributes(accumulator, node) {
        var transformString = node.getAttribute("data-fa-transform");
        if (transformString) {
          accumulator.transform = parseTransformString(transformString);
        }
        return accumulator;
      }, "parseNodeAttributes")
    };
  }, "hooks"),
  provides: /* @__PURE__ */ __name(function provides4(providers2) {
    providers2.generateAbstractTransformGrouping = function(_ref2) {
      var main = _ref2.main, transform = _ref2.transform, containerWidth = _ref2.containerWidth, iconWidth = _ref2.iconWidth;
      var outer = {
        transform: "translate(".concat(containerWidth / 2, " 256)")
      };
      var innerTranslate = "translate(".concat(transform.x * 32, ", ").concat(transform.y * 32, ") ");
      var innerScale = "scale(".concat(transform.size / 16 * (transform.flipX ? -1 : 1), ", ").concat(transform.size / 16 * (transform.flipY ? -1 : 1), ") ");
      var innerRotate = "rotate(".concat(transform.rotate, " 0 0)");
      var inner = {
        transform: "".concat(innerTranslate, " ").concat(innerScale, " ").concat(innerRotate)
      };
      var path = {
        transform: "translate(".concat(iconWidth / 2 * -1, " -256)")
      };
      var operations = {
        outer,
        inner,
        path
      };
      return {
        tag: "g",
        attributes: _objectSpread2({}, operations.outer),
        children: [{
          tag: "g",
          attributes: _objectSpread2({}, operations.inner),
          children: [{
            tag: main.icon.tag,
            children: main.icon.children,
            attributes: _objectSpread2(_objectSpread2({}, main.icon.attributes), operations.path)
          }]
        }]
      };
    };
  }, "provides")
};
var ALL_SPACE = {
  x: 0,
  y: 0,
  width: "100%",
  height: "100%"
};
function fillBlack(_abstract) {
  var force = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
  if (_abstract.attributes && (_abstract.attributes.fill || force)) {
    _abstract.attributes.fill = "black";
  }
  return _abstract;
}
__name(fillBlack, "fillBlack");
function deGroup(_abstract2) {
  if (_abstract2.tag === "g") {
    return _abstract2.children;
  } else {
    return [_abstract2];
  }
}
__name(deGroup, "deGroup");
var Masks = {
  hooks: /* @__PURE__ */ __name(function hooks6() {
    return {
      parseNodeAttributes: /* @__PURE__ */ __name(function parseNodeAttributes(accumulator, node) {
        var maskData = node.getAttribute("data-fa-mask");
        var mask = !maskData ? emptyCanonicalIcon() : getCanonicalIcon(maskData.split(" ").map(function(i) {
          return i.trim();
        }));
        if (!mask.prefix) {
          mask.prefix = getDefaultUsablePrefix();
        }
        accumulator.mask = mask;
        accumulator.maskId = node.getAttribute("data-fa-mask-id");
        return accumulator;
      }, "parseNodeAttributes")
    };
  }, "hooks"),
  provides: /* @__PURE__ */ __name(function provides5(providers2) {
    providers2.generateAbstractMask = function(_ref2) {
      var children = _ref2.children, attributes = _ref2.attributes, main = _ref2.main, mask = _ref2.mask, explicitMaskId = _ref2.maskId, transform = _ref2.transform;
      var mainWidth = main.width, mainPath = main.icon;
      var maskWidth = mask.width, maskPath = mask.icon;
      var trans = transformForSvg({
        transform,
        containerWidth: maskWidth,
        iconWidth: mainWidth
      });
      var maskRect = {
        tag: "rect",
        attributes: _objectSpread2(_objectSpread2({}, ALL_SPACE), {}, {
          fill: "white"
        })
      };
      var maskInnerGroupChildrenMixin = mainPath.children ? {
        children: mainPath.children.map(fillBlack)
      } : {};
      var maskInnerGroup = {
        tag: "g",
        attributes: _objectSpread2({}, trans.inner),
        children: [fillBlack(_objectSpread2({
          tag: mainPath.tag,
          attributes: _objectSpread2(_objectSpread2({}, mainPath.attributes), trans.path)
        }, maskInnerGroupChildrenMixin))]
      };
      var maskOuterGroup = {
        tag: "g",
        attributes: _objectSpread2({}, trans.outer),
        children: [maskInnerGroup]
      };
      var maskId = "mask-".concat(explicitMaskId || nextUniqueId());
      var clipId = "clip-".concat(explicitMaskId || nextUniqueId());
      var maskTag = {
        tag: "mask",
        attributes: _objectSpread2(_objectSpread2({}, ALL_SPACE), {}, {
          id: maskId,
          maskUnits: "userSpaceOnUse",
          maskContentUnits: "userSpaceOnUse"
        }),
        children: [maskRect, maskOuterGroup]
      };
      var defs = {
        tag: "defs",
        children: [{
          tag: "clipPath",
          attributes: {
            id: clipId
          },
          children: deGroup(maskPath)
        }, maskTag]
      };
      children.push(defs, {
        tag: "rect",
        attributes: _objectSpread2({
          fill: "currentColor",
          "clip-path": "url(#".concat(clipId, ")"),
          mask: "url(#".concat(maskId, ")")
        }, ALL_SPACE)
      });
      return {
        children,
        attributes
      };
    };
  }, "provides")
};
var MissingIconIndicator = {
  provides: /* @__PURE__ */ __name(function provides6(providers2) {
    var reduceMotion = false;
    if (WINDOW.matchMedia) {
      reduceMotion = WINDOW.matchMedia("(prefers-reduced-motion: reduce)").matches;
    }
    providers2.missingIconAbstract = function() {
      var gChildren = [];
      var FILL = {
        fill: "currentColor"
      };
      var ANIMATION_BASE = {
        attributeType: "XML",
        repeatCount: "indefinite",
        dur: "2s"
      };
      gChildren.push({
        tag: "path",
        attributes: _objectSpread2(_objectSpread2({}, FILL), {}, {
          d: "M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"
        })
      });
      var OPACITY_ANIMATE = _objectSpread2(_objectSpread2({}, ANIMATION_BASE), {}, {
        attributeName: "opacity"
      });
      var dot = {
        tag: "circle",
        attributes: _objectSpread2(_objectSpread2({}, FILL), {}, {
          cx: "256",
          cy: "364",
          r: "28"
        }),
        children: []
      };
      if (!reduceMotion) {
        dot.children.push({
          tag: "animate",
          attributes: _objectSpread2(_objectSpread2({}, ANIMATION_BASE), {}, {
            attributeName: "r",
            values: "28;14;28;28;14;28;"
          })
        }, {
          tag: "animate",
          attributes: _objectSpread2(_objectSpread2({}, OPACITY_ANIMATE), {}, {
            values: "1;0;1;1;0;1;"
          })
        });
      }
      gChildren.push(dot);
      gChildren.push({
        tag: "path",
        attributes: _objectSpread2(_objectSpread2({}, FILL), {}, {
          opacity: "1",
          d: "M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"
        }),
        children: reduceMotion ? [] : [{
          tag: "animate",
          attributes: _objectSpread2(_objectSpread2({}, OPACITY_ANIMATE), {}, {
            values: "1;0;0;0;0;1;"
          })
        }]
      });
      if (!reduceMotion) {
        gChildren.push({
          tag: "path",
          attributes: _objectSpread2(_objectSpread2({}, FILL), {}, {
            opacity: "0",
            d: "M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"
          }),
          children: [{
            tag: "animate",
            attributes: _objectSpread2(_objectSpread2({}, OPACITY_ANIMATE), {}, {
              values: "0;0;1;1;0;0;"
            })
          }]
        });
      }
      return {
        tag: "g",
        attributes: {
          "class": "missing"
        },
        children: gChildren
      };
    };
  }, "provides")
};
var SvgSymbols = {
  hooks: /* @__PURE__ */ __name(function hooks7() {
    return {
      parseNodeAttributes: /* @__PURE__ */ __name(function parseNodeAttributes(accumulator, node) {
        var symbolData = node.getAttribute("data-fa-symbol");
        var symbol = symbolData === null ? false : symbolData === "" ? true : symbolData;
        accumulator["symbol"] = symbol;
        return accumulator;
      }, "parseNodeAttributes")
    };
  }, "hooks")
};
var plugins = [InjectCSS, ReplaceElements, Layers, LayersCounter, LayersText, PseudoElements, MutationObserver$1, PowerTransforms, Masks, MissingIconIndicator, SvgSymbols];
registerPlugins(plugins, {
  mixoutsTo: api
});
api.noAuto;
api.config;
api.library;
api.dom;
api.parse;
api.findIconDefinition;
api.toHtml;
api.icon;
api.layer;
api.text;
api.counter;
let PLIMP = {};
let isMultipleSelectClassPresent = false;
const _PlaylistImporterInitializer = class _PlaylistImporterInitializer {
  constructor() {
  }
  static initialize() {
    this.multipleSelectClassObserver = void 0;
    _PlaylistImporterInitializer.hookInit();
    _PlaylistImporterInitializer.hookReady();
    _PlaylistImporterInitializer.hookRenderPlaylistDirectory();
    _PlaylistImporterInitializer.hookRenderSettings();
    _PlaylistImporterInitializer.hookDeletePlaylist();
    _PlaylistImporterInitializer.hookDeletePlaylistSound();
  }
  // Multiple Document Selection method to tell if multiple selection is enable
  static handleMultipleSelectMutations(mutationsList, observer) {
    for (const mutation of mutationsList) {
      if (mutation.type === "attributes" && mutation.attributeName === "class") {
        const newClassList = mutation.target.classList;
        const oldClassList = mutation.oldValue?.split(" ") || [];
        const multipleSelectClass = "multiple-select";
        isMultipleSelectClassPresent = !oldClassList.includes(multipleSelectClass) && newClassList.contains(multipleSelectClass);
      }
    }
  }
  static hookRenderPlaylistDirectory() {
    Hooks.on("renderPlaylistDirectory", (app, html, data) => {
      if (this.multipleSelectClassObserver == null || this.multipleSelectClassObserver == void 0) {
        this.multipleSelectClassObserver = new MutationObserver(this.handleMultipleSelectMutations);
        const observerOptions = {
          attributes: true,
          // Watch for attribute changes
          attributeFilter: ["class"],
          // Only watch the "class" attribute
          attributeOldValue: true
          // Include the old value of the attribute
        };
        this.multipleSelectClassObserver.observe(html, observerOptions);
      }
      html.getElementsByClassName("directory-footer")[0].style.display = "inherit";
      if (html.getElementsByClassName(`${CONSTANTS.MODULE_NAME}ImportButton`).length == 0) {
        const importPlaylistString = game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportButton`);
        const importButton = document.createElement("button");
        importButton.className += ` ${CONSTANTS.MODULE_NAME}ImportButton`;
        importButton.innerHTML = importPlaylistString;
        importButton.type = "button";
        importButton.style = "width: 100%; height:auto";
        if (game.user?.isGM || game.user?.can("SETTINGS_MODIFY")) {
          html.getElementsByClassName("directory-footer")[0].append(importButton);
          importButton.addEventListener("click", function(event) {
            debug("_____ START IMPORT SOUNDS _____");
            PLIMP.playlistImporter.playlistDirectoryInterface();
          });
        }
      }
      if (html.getElementsByClassName(`${CONSTANTS.MODULE_NAME}DeleteAllButton`).length == 0) {
        const deleteAllPlaylistString = game.i18n.localize(`${CONSTANTS.MODULE_NAME}.DeleteAllButton`);
        const deleteAllButton = document.createElement("button");
        deleteAllButton.className += ` ${CONSTANTS.MODULE_NAME}DeleteAllButton`;
        deleteAllButton.innerHTML = deleteAllPlaylistString;
        deleteAllButton.type = "button";
        deleteAllButton.style = "width: 100%; height:auto";
        if (game.user?.isGM || game.user?.can("SETTINGS_MODIFY")) {
          html.getElementsByClassName("directory-footer")[0].append(deleteAllButton);
          deleteAllButton.addEventListener("click", function(event) {
            PLIMP.playlistImporter._deleteAllPlaylistsAndFolders();
          });
        }
      }
      var directoriesList = html.getElementsByClassName("directory-list plain")[0];
      if (directoriesList == void 0 || directoriesList.className.search(`${CONSTANTS.MODULE_NAME}DirectoryList`) == -1) {
        directoriesList.className += ` ${CONSTANTS.MODULE_NAME}DirectoryList`;
        console.log(directoriesList);
        directoriesList.addEventListener("drop", (evt) => {
          if (isMultipleSelectClassPresent == true) {
            debug(`MULTIPLE SELECTION IS ENABLE : ${isMultipleSelectClassPresent}, So we stop DROP Event`);
            return;
          }
          debug("DROP EVENT on playlist tab directories list part");
          console.log(evt);
          var droppedFiles = evt.dataTransfer.files;
          if (droppedFiles.length == 0 && droppedFiles == void 0) {
            return;
          }
          var dropTarget = evt.target;
          var targetType = null;
          var targettedFolderName = null;
          var targettedPlaylistName = null;
          console.log(dropTarget);
          console.log(dropTarget.className);
          console.log(dropTarget.nodeName);
          var className = dropTarget.className;
          var nodeName = dropTarget.nodeName;
          var folderString = "FOLDER";
          var playlistString = "PLAYLIST";
          var plainString = "PLAIN";
          if (className === "folder-name ellipsis") {
            targetType = folderString;
            targettedFolderName = dropTarget.innerText;
          }
          if (className === "folder-header") {
            targetType = folderString;
            targettedFolderName = dropTarget.outerText;
          }
          if (className === "entry-name playlist-name ellipsis") {
            targetType = playlistString;
            targettedPlaylistName = game.playlists.get(dropTarget.offsetParent.dataset.entryId).name;
          }
          if (className === "playlist-header") {
            targetType = playlistString;
            targettedPlaylistName = game.playlists.get(dropTarget.offsetParent.dataset.entryId).name;
          }
          if (className === "ellipsis" && nodeName === "LABEL") {
            targetType = playlistString;
            targettedPlaylistName = game.playlists.get(dropTarget.offsetParent.dataset.entryId).name;
          }
          if (className === "playlist-sounds plain") {
            targetType = playlistString;
            targettedPlaylistName = game.playlists.get(dropTarget.offsetParent.dataset.entryId).name;
          }
          if (className === "directory-list plain playlist_importDirectoryList") {
            targetType = plainString;
          }
          if (targetType == null) {
            targetType = plainString;
          }
          debug(
            `Target type is : ${targetType}, targeted folder is : ${targettedFolderName}, targeted playlist is : ${targettedPlaylistName}`
          );
          var audioFiles = [];
          for (var file of droppedFiles) {
            if (PlaylistImporter._validateAudioExtension(PlaylistImporter._getFileExtension(file.name))) {
              audioFiles.push(file);
            }
          }
          PLIMP.playlistImporter._DropImportAudioFiles(
            targetType,
            targettedFolderName,
            targettedPlaylistName,
            audioFiles
          );
        });
      }
    });
  }
  static _removeSound(playlistName, soundNames) {
    const currentList = game.settings.get(CONSTANTS.MODULE_NAME, "songs");
    soundNames.forEach((soundName) => {
      const trackName = PlaylistImporter._convertToUserFriendly(PlaylistImporter._getBaseName(soundName));
      const mergedName = (playlistName + trackName).toLowerCase();
      if (trackName && playlistName) {
        if (currentList[mergedName]) {
          delete currentList[mergedName];
        }
      }
    });
    game.settings.set(CONSTANTS.MODULE_NAME, "songs", currentList);
  }
  static hookDeletePlaylist() {
    Hooks.on("deletePlaylist", (playlist, flags, id) => {
      const playlistName = playlist.name;
      const soundObjects = playlist.sounds;
      const sounds = [];
      for (let i = 0; i < soundObjects.length; ++i) {
        sounds.push(soundObjects[i].path);
      }
      _PlaylistImporterInitializer._removeSound(playlistName, sounds);
    });
  }
  static hookDeletePlaylistSound() {
    Hooks.on("deletePlaylistSound", (playlist, data, flags, id) => {
      const playlistName = playlist.name;
      const soundName = data.path;
      _PlaylistImporterInitializer._removeSound(playlistName, [soundName]);
    });
  }
  static hookRenderSettings() {
    Hooks.on("renderSettings", (app, html) => {
      const clearMemoryString = game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ClearMemory`);
      var importButton = document.createElement("button");
      var importButtonText = document.createTextNode(clearMemoryString);
      importButton.appendChild(importButtonText);
      importButton.addEventListener("click", function() {
        PLIMP.playlistImporter.clearMemoryInterface();
      });
      if (game.user?.isGM || game.user?.can("SETTINGS_MODIFY")) {
        html.getElementsByClassName("settings flexcol")[0].appendChild(importButton);
      }
    });
  }
  static hookInit() {
    Hooks.once("init", () => {
    });
  }
  static hookReady() {
    Hooks.on("ready", () => {
      PLIMP.playlistImporter = new PlaylistImporter();
      _PlaylistImporterInitializer._registerSettings();
    });
  }
  static _registerSettings() {
    registerSettings();
  }
};
__name(_PlaylistImporterInitializer, "PlaylistImporterInitializer");
let PlaylistImporterInitializer = _PlaylistImporterInitializer;
const _PlaylistImporter = class _PlaylistImporter {
  constructor() {
    this.DEBUG = false;
  }
  /*  --------------------------------------  */
  /*           Helper functions               */
  /*  --------------------------------------  */
  /**
   * Grabs the most recent folder name. Used in playlist naming.
   * @private
   * @param {string} filePath
   */
  static _getBaseName(filePath) {
    return filePath.split("/").reverse()[0];
  }
  /**
   *
   * @param {string} fileName the name of the file, only the name (exemple a.txt) not the path
   */
  static _getFileExtension(fileName) {
    var split = fileName.split(".");
    if (split.length === 1 || split[0] === "" && split.length === 2) {
      return "";
    }
    return split.pop();
  }
  /**
   *
   * @param {*} fileExt the file extension
   * @returns true if the extension of the file is an audio one (one of the regex), else false
   */
  static _validateAudioExtension(fileExt) {
    return !!fileExt.match(/(aac|flac|m4a|mid|mp3|ogg|opus|wav|webm)+/g);
  }
  /**
   * Validates the audio extension to be of type 'CONST.AUDIO_FILE_EXTENSIONS'
   * @private
   * @param {string} fileName
   */
  _validateFileType(fileName) {
    const ext = fileName.split(".").pop();
    info(`Extension is determined to be (${ext}).`);
    return !!ext.match(/(aac|flac|m4a|mid|mp3|ogg|opus|wav|webm)+/g);
  }
  /**
   *
   * @param match
   * @param p1
   * @param p2
   * @param p3
   * @param offset
   * @param input_string
   * @returns {string}
   * @private
   */
  static _convertCamelCase(match, p1, p2, p3, offset, input_string) {
    let replace3;
    const small = ["a", "an", "at", "and", "but", "by", "for", "if", "nor", "on", "of", "or", "so", "the", "to", "yet"];
    if (p3) {
      if (small.includes(p2.toLowerCase())) {
        p2 = p2.toLowerCase();
      }
      replace3 = p1 + " " + p2 + " " + p3;
    } else {
      replace3 = p1 + " " + p2;
    }
    return replace3;
  }
  /**
   * Formats the filenames of songs to something more readable. You can add additional REGEX for other audio extensions
   * 'CONST.AUDIO_FILE_EXTENSIONS'.
   * @private
   * @param {string} name
   */
  static _convertToUserFriendly(name) {
    let words = [];
    const small = ["a", "an", "at", "and", "but", "by", "for", "if", "nor", "on", "of", "or", "so", "the", "to", "yet"];
    const regexReplace = new RegExp(game.settings?.get(CONSTANTS.MODULE_NAME, "customRegexDelete"));
    name = decodeURIComponent(name);
    name = name.split(/(.aac|.flac|.m4a|.mid|.mp3|.ogg|.opus|.wav|.webm)+/g)[0].replace(regexReplace, "").replace(/[_]+/g, " ");
    while (name !== name.replace(/([a-z])([A-Z][a-z]*)([A-Z])?/, _PlaylistImporter._convertCamelCase)) {
      name = name.replace(/([a-z])([A-Z][a-z]*)([A-Z])?/, _PlaylistImporter._convertCamelCase);
    }
    words = name.replace(/\s+/g, " ").trim().split(" ");
    for (let i = 0; i < words.length; i++) {
      if (i === 0 || i === words.length - 1 || !small.includes(words[i])) {
        try {
          words[i] = words[i][0].toUpperCase() + words[i].substr(1);
        } catch (e) {
          error(e);
          error(`Error in attempting to parse song ${name}`);
        }
      }
    }
    name = words.join(" ");
    debug(`Converting playlist name to eliminate spaces and extension: ${name}.`);
    return name;
  }
  /**
   * Waits for the creation of a playlist in a separate function for readability.
   * @param {string} playlistName
   */
  _generatePlaylist(playlistName, dirPath) {
    return new Promise(async (resolve, reject) => {
      let playlist = game.playlists?.contents.find((p2) => p2.name === playlistName);
      let playlistExists = playlist ? true : false;
      const fadeTime = parseInt(game.settings?.get(CONSTANTS.MODULE_NAME, "fadeTime"), 10);
      if (playlistExists) {
        const shouldOverridePlaylist = game.settings?.get(CONSTANTS.MODULE_NAME, "shouldOverridePlaylist");
        if (shouldOverridePlaylist) {
          info(`Retrieved playlist '${playlist.id}|${playlist.name}'`);
          info(`Update playlist '${playlist.id}|${playlist.name}'`);
        }
        await playlist?.setFlag(CONSTANTS.MODULE_NAME, "isPlaylistImported", true);
        await playlist?.setFlag(CONSTANTS.MODULE_NAME, "directoryPath", dirPath);
        try {
          info(`Successfully retrieved playlist: ${playlistName}`);
          resolve(true);
        } catch (e) {
          error(e);
          reject(false);
        }
      } else {
        try {
          info(`Create playlist '${playlistName}'`);
          let playlistCreated = await Playlist.create({
            name: playlistName,
            permission: {
              default: 0
            },
            flags: {},
            sounds: [],
            // Put this ternary because with fadeTime = 0 as default value the import crash,
            // so we put to undefined instead
            fade: fadeTime !== 0 ? fadeTime : void 0,
            mode: 0,
            playing: false
          });
          await playlistCreated?.setFlag(CONSTANTS.MODULE_NAME, "isPlaylistImported", true);
          await playlistCreated?.setFlag(CONSTANTS.MODULE_NAME, "directoryPath", dirPath);
          info(`Successfully created playlist: ${playlistCreated.name}`);
          resolve(true);
        } catch (e) {
          error(e);
          reject(false);
        }
      }
      resolve(false);
    });
  }
  /**
   * Given a path and a playlist name, it will search the path for all files and attempt to add them the created playlist using playlistName.
   * @param {string} source
   * @param {string} path
   * @param {string} playlistName
   */
  _getItemsFromDir(source, path, playlistName, options) {
    const dupCheck = game.settings.get(CONSTANTS.MODULE_NAME, "enableDuplicateChecking");
    const shouldRepeat = game.settings.get(CONSTANTS.MODULE_NAME, "shouldRepeat");
    const shouldStream = game.settings.get(CONSTANTS.MODULE_NAME, "shouldStream");
    let logVolume = parseFloat(game.settings?.get(CONSTANTS.MODULE_NAME, "logVolume"));
    if (isNaN(logVolume)) {
      debug(`Invalid type logVolume`);
      return;
    }
    logVolume = foundry.audio.AudioHelper.inputToVolume(logVolume);
    const playlist = game.playlists?.contents.find((p2) => p2.name === playlistName);
    if (!playlist) {
      warn("Cannot find a playlist with name '" + playlistName + "'", true);
    }
    return new Promise(async (resolve, reject) => {
      foundry.applications.apps.FilePicker.implementation.browse(source, path, options).then(
        async function(resp) {
          const localFiles = resp.files;
          for (const fileName of localFiles) {
            const valid = await this._validateFileType(fileName);
            if (valid) {
              const trackName = _PlaylistImporter._convertToUserFriendly(_PlaylistImporter._getBaseName(fileName));
              const currentList = await game.settings.get(CONSTANTS.MODULE_NAME, "songs");
              const currentPlaylist = game.playlists?.contents.find((playlist2) => {
                return playlist2 && playlist2.name == playlistName;
              });
              if (currentPlaylist) {
                const currentSound = currentPlaylist.sounds.find((sound) => {
                  return sound && sound.name == trackName;
                });
                if (dupCheck && currentSound)
                  ;
                else {
                  debug(`Song ${trackName} not in list ${playlistName}.`);
                  await this._addSong(
                    currentList,
                    trackName,
                    fileName,
                    playlistName,
                    playlist,
                    shouldRepeat,
                    logVolume,
                    shouldStream
                  );
                  debug(`Song ${trackName} added to list ${playlistName}.`);
                }
              }
            } else {
              debug(
                `Determined ${fileName} to be of an invalid ext. If you believe this to be an error contact me on Discord.`
              );
            }
          }
          resolve(true);
        }.bind(this)
      );
    });
  }
  async _addSong(currentList, trackName, fileName, playlistName, playlist, shouldRepeat, logVolume, shouldStream) {
    currentList[(playlistName + trackName).toLowerCase()] = true;
    await game.settings.set(CONSTANTS.MODULE_NAME, "songs", currentList);
    const mySoundLists = playlist.sounds?.filter((s) => s.name === trackName) || [];
    const mySoundExists = mySoundLists.length > 0 ? true : false;
    const shouldOverridePlaylist = game.settings?.get(CONSTANTS.MODULE_NAME, "shouldOverridePlaylist");
    if (mySoundExists && !shouldOverridePlaylist) {
      trackName = trackName + "-" + mySoundLists.length;
    }
    const sound = playlist.sounds.find((s) => s.name === trackName);
    const soundExists = sound ? true : false;
    if (soundExists) {
      if (shouldOverridePlaylist) {
        info(`Retrieved sound '${sound.id}|${trackName}' on playlist '${playlist.id}|${playlist.name}'`);
        await playlist.updateEmbeddedDocuments(
          "PlaylistSound",
          [{ id: sound.id, name: trackName, path: fileName, repeat: shouldRepeat, volume: logVolume }],
          {}
        );
        info(`Updated sound '${sound.id}|${trackName}' on playlist '${playlist.id}|${playlist.name}'`);
      }
    } else {
      await playlist.createEmbeddedDocuments(
        "PlaylistSound",
        [{ name: trackName, path: fileName, repeat: shouldRepeat, volume: logVolume }],
        {}
      );
      info(`Created sound '${trackName}' on playlist '${playlist.id}|${playlist.name}'`);
    }
  }
  /**
   * A helper function designed to prompt the player of task completion.
   */
  _playlistCompletePrompt() {
    new foundry.applications.api.DialogV2({
      window: { title: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.OperationFinishTitle`) },
      content: `<p>${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.OperationFinishContent`)}</p>`,
      buttons: [
        {
          // just an OK button
          action: "ok",
          icon: "fa-regular fa-check",
          label: "Ok"
        }
      ],
      default: "ok",
      submit: (result) => {
        info(result);
      }
    }).render({ force: true });
  }
  /**
   *
   * @returns
   */
  async _playlistStatusPrompt() {
    const importInProgressDiv = document.createElement("div");
    const progressBar = document.createElement("progress");
    var counts = await this._countTotalAudioFiles(
      game.settings.get(CONSTANTS.MODULE_NAME, "source"),
      game.settings.get(CONSTANTS.MODULE_NAME, "folderDir")
    );
    var total = counts.reduce((sum, acc) => sum + acc, 0);
    progressBar.max = total;
    progressBar.value = 0;
    const contentTextNode = document.createTextNode(
      `${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportInProgressContent`)}`
    );
    const counterparagraph = document.createElement("P");
    const countersTextNode = document.createTextNode(
      `0 / ${counts[0]} ${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportInProgressFolders`)}
      | 0 / ${counts[1]} ${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportInProgressPlaylists`)}
      | 0 / ${counts[2]} ${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportInProgressAudioFiles`)}`
    );
    importInProgressDiv.appendChild(contentTextNode);
    importInProgressDiv.appendChild(progressBar);
    counterparagraph.appendChild(countersTextNode);
    importInProgressDiv.appendChild(counterparagraph);
    const progressDialog = await new foundry.applications.api.DialogV2({
      window: { title: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportInProgressTitle`) },
      content: importInProgressDiv,
      buttons: [
        {
          // just a close button in case of
          action: "close",
          icon: "fa-regular fa-check",
          label: "Close this prompt"
        }
      ],
      default: "close",
      submit: (result) => {
        info(result);
      }
    }).render({ force: true });
    return {
      progressDialog,
      progressMaxNumberOfFolders: counts[0],
      progressMaxNumberOfPlaylists: counts[1],
      progressMaxNumberOfAudioFiles: counts[2],
      progressNumberOfFolders: 0,
      progressNumberOfPlaylists: 0,
      progressNumberOfAudioFiles: 0
    };
  }
  /**
   * @summary Update paragraph and progressBar dom object in the progress prompt meanwhile import
   * @param {*} progressPromptObject a big object that contain a lot of info (all counter and maximum values) + the Dialog object to access the progress bar and others...
   * @param {*} folderIncrement of how much to increment the folders count
   * @param {*} playlistIncrement of how much to increment the playlists count
   * @param {*} audioFileIncrement of how much to increment the audiofiles count
   */
  _incrementPlaylistStatusPromptProgressBar(progressPromptObject, folderIncrement = 0, playlistIncrement = 0, audioFileIncrement = 0) {
    progressPromptObject.progressNumberOfFolders += folderIncrement;
    progressPromptObject.progressNumberOfPlaylists += playlistIncrement;
    progressPromptObject.progressNumberOfAudioFiles += audioFileIncrement;
    debug(`progress bar update progressDialog.element : ${progressPromptObject.progressDialog.element}`);
    if (progressPromptObject.progressDialog.element != null) {
      var progressBar = progressPromptObject.progressDialog.element.querySelector("progress");
      if (progressBar != void 0 && progressBar != null) {
        progressBar.value += folderIncrement + playlistIncrement + audioFileIncrement;
      }
      var pCounters = progressPromptObject.progressDialog.element.querySelector("p");
      if (pCounters != void 0 && pCounters != null) {
        pCounters.innerHTML = `${progressPromptObject.progressNumberOfFolders} / ${progressPromptObject.progressMaxNumberOfFolders} ${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportInProgressFolders`)}
        | ${progressPromptObject.progressNumberOfPlaylists} / ${progressPromptObject.progressMaxNumberOfPlaylists} ${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportInProgressPlaylists`)}
        | ${progressPromptObject.progressNumberOfAudioFiles} / ${progressPromptObject.progressMaxNumberOfAudioFiles} ${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportInProgressAudioFiles`)}`;
      }
      if (progressBar.value == progressBar.max) {
        progressPromptObject.progressDialog.close();
      }
    }
  }
  /**
   * A helper function designed to clear the stored history of songs
   */
  _clearSongHistory() {
    game.settings.set(CONSTANTS.MODULE_NAME, "songs", {});
  }
  /**
   * @name _countTotalAudioFiles
   * @param {*} source
   * @param {*} path
   * @async
   * @description A method to access and browse the folders structure to count all Folders, Playlists and Audio files, Needed for the progression prompt
   * @returns Return an Array of 3 values
   *  - countFolders : the number of folders to create
   *  - countPlaylists : the number of playlists to create
   *  - countAudioFiles : the total number of audio files to imports
   */
  async _countTotalAudioFiles(source, path) {
    const skipEmptyFolders = game.settings.get(CONSTANTS.MODULE_NAME, "skipEmptyFolders");
    debug(`Setting skipEmptyFolders value : ${skipEmptyFolders}`);
    var countAudioFiles = 0;
    var countFolders = 0;
    var countPlaylists = 0;
    var stack = [];
    stack.push(await foundry.applications.apps.FilePicker.implementation.browse(source, path));
    debugListOfFilePicker("Stack of File Picker object : ", stack);
    while (stack.length > 0) {
      var fp = stack.pop();
      var currentFoundryFolder = await game.folders.getName(fp.target);
      currentFoundryFolder != void 0 && currentFoundryFolder.type === "Playlist" ? currentFoundryFolder.id : null;
      var dirs = fp.dirs;
      for (var dir of dirs) {
        var fpDir = await foundry.applications.apps.FilePicker.implementation.browse(source, dir);
        if (skipEmptyFolders == true && fpDir.dirs.length == 0 && fpDir.files.filter(
          (file) => _PlaylistImporter._validateAudioExtension(_PlaylistImporter._getFileExtension(file))
        ).length == 0) {
          debug(`Folder ${dir} is Skipped because empty`);
          continue;
        }
        countFolders += 1;
        stack.push(await fpDir);
      }
      countPlaylists += 1;
      var allFiles = fp.files;
      const audioFiles = allFiles.filter(
        (file) => _PlaylistImporter._validateAudioExtension(_PlaylistImporter._getFileExtension(file))
      );
      countAudioFiles += audioFiles.length;
    }
    debug(`COUNTS => FOLDERS : ${countFolders}, PLAYLISTS : ${countPlaylists}, AUDIO_FILES : ${countAudioFiles}`);
    return [countFolders, countPlaylists, countAudioFiles];
  }
  _deleteAllPlaylistsAndFolders() {
    const allFolders = game.folders?.contents;
    const playlistFolders = allFolders.filter((folder) => folder.type === "Playlist");
    const taggedPlaylistFolders = playlistFolders.filter(
      (playlistFolder) => playlistFolder.getFlag(CONSTANTS.MODULE_NAME, "isPlaylistImported") == true
    );
    debug("_____ START DELETE ALL TAGGED FOLDERS _____");
    for (const folder of taggedPlaylistFolders) {
      debug("DELETING FOLDER : ", folder);
      folder.delete();
    }
    const playlists = game.playlists?.contents;
    debug("_____ START DELETE ALL TAGGED PLAYLISTS _____");
    for (const playlist of playlists) {
      const playlistHasFlag = playlist.getFlag(CONSTANTS.MODULE_NAME, "isPlaylistImported");
      if (playlistHasFlag && playlistHasFlag == true) {
        debug("DELETING PLAYLIST : ", playlist);
        playlist.delete();
      }
    }
  }
  /*  --------------------------------------  */
  /*                 Interface                */
  /*  --------------------------------------  */
  clearMemoryInterface() {
    new foundry.applications.api.DialogV2({
      window: { title: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ClearMemoryTitle`) },
      content: `<p>${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ClearMemoryDescription`)}</p>`,
      buttons: [
        {
          // First Button to validate the imports clearing
          action: "clearing",
          label: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ClearMemoryWarning`)
        },
        {
          // Second button to cancel
          action: "cancel",
          label: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.CancelOperation`)
        }
      ],
      default: "cancel",
      // Buttons result processing
      submit: (result) => {
        if (result === "clearing") {
          info("Clearing imported playlists");
          this._clearSongHistory();
        } else
          warn(`Clearing Canceled`);
      }
    }).render({ force: true });
  }
  playlistDirectoryInterface() {
    new foundry.applications.api.DialogV2({
      window: { title: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportMusicTitle`) },
      content: `<p>${game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportMusicDescription`)}</p>`,
      buttons: [
        {
          // First Button to validate the mass import
          action: "import",
          icon: "fa-regular fa-check",
          label: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.ImportMusicLabel`)
        },
        {
          // Second button to cancel
          action: "cancel",
          icon: "fa-regular fa-x",
          label: game.i18n.localize(`${CONSTANTS.MODULE_NAME}.CancelOperation`)
        }
      ],
      default: "cancel",
      // Buttons result processing
      submit: (result) => {
        if (result === "import") {
          debug(
            `Is ShouldDeletePlaylist setting set : ${game.settings.get(CONSTANTS.MODULE_NAME, "shouldDeletePlaylist")}`
          );
          if (game.settings.get(CONSTANTS.MODULE_NAME, "shouldDeletePlaylist") == true) {
            debug("Delete All before re-importing");
            this._deleteAllPlaylistsAndFolders();
          }
          info("Starting Import");
          debug(
            "Value of Should Use New Folder Structure Creation : ",
            game.settings.get(CONSTANTS.MODULE_NAME, "shouldUseNewFolderStructureCreation")
          );
          if (game.settings.get(CONSTANTS.MODULE_NAME, "shouldUseNewFolderStructureCreation") == true) {
            debug("USE NEW PLAYLIST IMPORT METHOD WITH FOLDERS STRUCTURE");
            this.neoBeginPlaylistImport(
              game.settings.get(CONSTANTS.MODULE_NAME, "source"),
              game.settings.get(CONSTANTS.MODULE_NAME, "folderDir")
            );
          } else {
            debug("USE BASE PLAYLIST IMPORT METHOD WITH ONLY PLAYLISTS");
            this.beginPlaylistImport(
              game.settings.get(CONSTANTS.MODULE_NAME, "source"),
              game.settings.get(CONSTANTS.MODULE_NAME, "folderDir")
            );
          }
        } else
          debug(`import Canceled`);
      }
    }).render({ force: true });
  }
  /**
   * @name neoBeginPlaylistImport
   * @async
   * @description New Playlist import method for FOLDERS and PLAYLISTS creation
   * @param {string} source
   * @param {string} path
   */
  async neoBeginPlaylistImport(source, path) {
    var progressPromptObject = await this._playlistStatusPrompt();
    debug(`the progress prompt big object : ${progressPromptObject}`);
    const skipEmptyFolders = game.settings.get(CONSTANTS.MODULE_NAME, "skipEmptyFolders");
    debug(`Setting skipEmptyFolders value : ${skipEmptyFolders}`);
    const dupCheck = game.settings.get(CONSTANTS.MODULE_NAME, "enableDuplicateChecking");
    const shouldOverride = game.settings.get(CONSTANTS.MODULE_NAME, "shouldOverridePlaylist");
    const shouldRepeat = game.settings.get(CONSTANTS.MODULE_NAME, "shouldRepeat");
    const shouldStream = game.settings.get(CONSTANTS.MODULE_NAME, "shouldStream");
    let logVolume = parseFloat(game.settings?.get(CONSTANTS.MODULE_NAME, "logVolume"));
    if (isNaN(logVolume)) {
      debug(`Invalid type logVolume`);
      return;
    }
    logVolume = foundry.audio.AudioHelper.inputToVolume(logVolume);
    debug(
      "LISTING MODULE SETTINGS FOR FOLDER AND PLAYLISTS : ",
      `enable duplicate : ${dupCheck}, should overwrite ${shouldOverride}, should repeat : ${shouldRepeat}, should stream : ${shouldStream}, volume : ${logVolume}`
    );
    var stack = [];
    stack.push(await foundry.applications.apps.FilePicker.implementation.browse(source, path));
    while (stack.length > 0) {
      debugListOfFilePicker("Stack of File Picker object : ", stack);
      var fp = stack.pop();
      debug("_____Poped element from stack : ", fp.target);
      var currentFoundryFolder = game.folders.getName(_PlaylistImporter._convertToUserFriendly(_PlaylistImporter._getBaseName(fp.target)));
      var parentfolderId = currentFoundryFolder != void 0 && currentFoundryFolder.type === "Playlist" ? currentFoundryFolder.id : null;
      var dirs = fp.dirs;
      for (var dir of dirs) {
        var fpDir = await foundry.applications.apps.FilePicker.implementation.browse(source, dir);
        if (skipEmptyFolders == true && fpDir.dirs.length == 0 && fpDir.files.filter(
          (file) => _PlaylistImporter._validateAudioExtension(_PlaylistImporter._getFileExtension(file))
        ).length == 0) {
          debug(`Folder ${dir} is Skipped because empty`);
          continue;
        }
        var newPlaylistFolder = await Folder.create({
          name: _PlaylistImporter._convertToUserFriendly(_PlaylistImporter._getBaseName(dir)),
          type: "Playlist",
          folder: parentfolderId,
          color: "#000000"
        });
        newPlaylistFolder.setFlag(CONSTANTS.MODULE_NAME, "isPlaylistImported", true);
        debug(
          `Created folder : ${newPlaylistFolder.name} in folder : ${currentFoundryFolder != void 0 ? currentFoundryFolder.name : "root"}`
        );
        this._incrementPlaylistStatusPromptProgressBar(progressPromptObject, 1, 0, 0);
        stack.push(await fpDir);
      }
      var pl = game.playlists.getName(_PlaylistImporter._convertToUserFriendly(_PlaylistImporter._getBaseName(fp.target)));
      if (shouldOverride == true && pl != void 0) {
        debug(
          `Playlist : ${pl} in folder : ${currentFoundryFolder != void 0 ? currentFoundryFolder.name : "root"} already exist, we override it instead`
        );
      } else {
        pl = await Playlist.create({ name: _PlaylistImporter._convertToUserFriendly(_PlaylistImporter._getBaseName(fp.target)), folder: parentfolderId, mode: shouldStream ? 0 : -1 });
        await pl.setFlag(CONSTANTS.MODULE_NAME, "isPlaylistImported", true);
        debug(
          `Created playlist : ${pl} in folder : ${currentFoundryFolder != void 0 ? currentFoundryFolder.name : "root"}`
        );
      }
      this._incrementPlaylistStatusPromptProgressBar(progressPromptObject, 0, 1, 0);
      var allFiles = fp.files;
      const audioFiles = allFiles.filter(
        (file) => _PlaylistImporter._validateAudioExtension(_PlaylistImporter._getFileExtension(file))
      );
      for (var soundFile of audioFiles) {
        var soundName = _PlaylistImporter._convertToUserFriendly(_PlaylistImporter._getBaseName(soundFile));
        if (dupCheck == true && pl.collections.sounds.getName(soundName) != void 0) {
          debug(`Audio ${soundName} already exist in the playlist ${pl.name}, we skip this it`);
        } else {
          await pl.createEmbeddedDocuments(
            "PlaylistSound",
            [{ name: soundName, path: soundFile, repeat: shouldRepeat, volume: logVolume }],
            {}
          );
          debug(`Add Audio : ${soundName} in Playlist : ${pl.name}`);
        }
        this._incrementPlaylistStatusPromptProgressBar(progressPromptObject, 0, 0, 1);
      }
    }
    this._playlistCompletePrompt();
  }
  /**
   * Called by the dialogue to begin the importation process. This is the function that starts the process.
   * @param {string} source
   * @param {string} path
   */
  async beginPlaylistImport(source, path) {
    const shouldDeletePlaylist = game.settings.get(CONSTANTS.MODULE_NAME, "shouldDeletePlaylist");
    if (shouldDeletePlaylist) {
      const playlists = game.playlists?.contents;
      for (const playlist of playlists) {
        const playlistHasFlag = playlist.getFlag(CONSTANTS.MODULE_NAME, "isPlaylistImported");
        if (String(playlistHasFlag) === "true") {
          await playlist.delete();
        }
      }
    }
    const options = {};
    if (source === "s3") {
      options["bucket"] = game.settings.get(CONSTANTS.MODULE_NAME, "bucket");
    }
    foundry.applications.apps.FilePicker.implementation.browse(source, path, options).then(async (resp) => {
      try {
        const localDirs = resp.dirs || [];
        let finishedDirs = 0;
        const dirName = resp.target;
        const playlistName = _PlaylistImporter._convertToUserFriendly(_PlaylistImporter._getBaseName(dirName));
        const success = await this._generatePlaylist(playlistName, dirName);
        debug(`TT: ${dirName}: ${success} on creating playlists`);
        await this._getItemsFromDir(source, dirName, playlistName, options);
        if (game.settings.get(CONSTANTS.MODULE_NAME, "skipEmptyFolders")) {
          this._deletePlaylistIfEmpty(playlistName);
        }
        for (const dirName2 of localDirs) {
          if (resp.target != dirName2 && !this._blackList.includes(dirName2)) {
            finishedDirs = this._searchOnSubFolder(source, dirName2, options, playlistName, finishedDirs);
            this._blackList.push(dirName2);
          }
        }
        $("#finished_playlists").html(++finishedDirs);
        debug(`Operation Completed. Thank you!`);
        $("#total_playlists").html(this._blackList.length);
        this._playlistCompletePrompt();
      } finally {
        this._blackList = [];
      }
    });
  }
  _blackList = [];
  _searchOnSubFolder(source, path, options, dirNameParent, finishedDirs) {
    foundry.applications.apps.FilePicker.implementation.browse(source, path, options).then(async (resp) => {
      const localDirs = resp.dirs || [];
      const dirName = resp.target;
      const playlistName = _PlaylistImporter._convertToUserFriendly(_PlaylistImporter._getBaseName(dirName));
      let dirNameCustom = dirNameParent ? dirNameParent + "_" + playlistName : playlistName;
      if (game.settings.get(CONSTANTS.MODULE_NAME, "maintainOriginalFolderName")) {
        dirNameCustom = playlistName;
      }
      const myPlaylistLists = game.playlists?.contents.filter((p2) => p2.name === dirNameCustom) || [];
      const myPlaylistExists = myPlaylistLists.length > 0 ? true : false;
      const shouldOverridePlaylist = game.settings?.get(CONSTANTS.MODULE_NAME, "shouldOverridePlaylist");
      if (myPlaylistExists && !shouldOverridePlaylist) {
        dirNameCustom = dirNameCustom + "-" + myPlaylistLists.length;
      }
      const success = await this._generatePlaylist(dirNameCustom, dirName);
      if (this.DEBUG)
        console.log(`TT: ${dirName}: ${success} on creating playlists`);
      await this._getItemsFromDir(source, dirName, dirNameCustom, options);
      if (game.settings.get(CONSTANTS.MODULE_NAME, "skipEmptyFolders")) {
        this._deletePlaylistIfEmpty(playlistName);
      }
      for (const dirName2 of localDirs) {
        if (resp.target != dirName2 && !this._blackList.includes(dirName2)) {
          finishedDirs = this._searchOnSubFolder(source, dirName2, options, dirNameCustom, finishedDirs);
          this._blackList.push(dirName2);
        }
      }
      return finishedDirs;
    });
  }
  /**
   * Deletes a playlist if it exists and contains no sounds.
   *
   * @param {string} playlistName - The name of the playlist to check and potentially delete.
   */
  _deletePlaylistIfEmpty(playlistName) {
    const playlist = game.playlists?.contents.find((p2) => p2.name === playlistName);
    if (playlist && playlist.sounds.size == 0) {
      info(`Deleting empty playlist: ${playlistName}`);
      playlist.delete();
    }
  }
  /**
   *
   * @param {*} targetType The type of target between [PLAIN, FOLDER, PLAYLIST], will serve to define what behaviours to apply
   * @param {*} targettedFolderName  the targetted folder on which the files were dropped
   * @param {*} targettedPlaylistName the targetted playlist on which the files were dropped
   * @param {*} audioFiles the audio files to upload to foundryVtt server and import
   * @returns
   */
  async _DropImportAudioFiles(targetType, targettedFolderName, targettedPlaylistName, audioFiles) {
    var source = game.settings.get(CONSTANTS.MODULE_NAME, "source");
    var rootDir = game.settings.get(CONSTANTS.MODULE_NAME, "folderDir");
    var folderDir = targettedFolderName;
    debug(`source : ${source}, root dir : ${rootDir}, folder dir : ${folderDir}`);
    const skipEmptyFolders = game.settings.get(CONSTANTS.MODULE_NAME, "skipEmptyFolders");
    debug(`Setting skipEmptyFolders value : ${skipEmptyFolders}`);
    const dupCheck = game.settings.get(CONSTANTS.MODULE_NAME, "enableDuplicateChecking");
    const shouldOverride = game.settings.get(CONSTANTS.MODULE_NAME, "shouldOverridePlaylist");
    const shouldRepeat = game.settings.get(CONSTANTS.MODULE_NAME, "shouldRepeat");
    const shouldStream = game.settings.get(CONSTANTS.MODULE_NAME, "shouldStream");
    let logVolume = parseFloat(game.settings?.get(CONSTANTS.MODULE_NAME, "logVolume"));
    if (isNaN(logVolume)) {
      debug(`Invalid type logVolume`);
      return;
    }
    logVolume = foundry.audio.AudioHelper.inputToVolume(logVolume);
    debug(
      "LISTING MODULE SETTINGS FOR FOLDER AND PLAYLISTS : ",
      `enable duplicate : ${dupCheck}, should overwrite ${shouldOverride}, should repeat : ${shouldRepeat}, should stream : ${shouldStream}, volume : ${logVolume}`
    );
    var targettedImportPlaylist = null;
    if (targetType === "PLAIN") {
      targettedPlaylistName = "Dropped_Audios";
      var pl = await Playlist.create({ name: targettedPlaylistName, mode: shouldStream ? 0 : -1 });
      await pl.setFlag(CONSTANTS.MODULE_NAME, "isPlaylistImported", true);
      debug(`Created playlist : ${pl}`);
      targettedImportPlaylist = pl;
    } else if (targetType === "FOLDER") {
      var targettedFolderId = game.folders.getName(targettedFolderName).id;
      targettedPlaylistName = "Dropped_Audios";
      var pl = await Playlist.create({
        name: targettedPlaylistName,
        folder: targettedFolderId,
        mode: shouldStream ? 0 : -1
      });
      await pl.setFlag(CONSTANTS.MODULE_NAME, "isPlaylistImported", true);
      debug(`Created playlist : ${pl} in folder ${targettedFolderName}`);
      targettedImportPlaylist = pl;
      rootDir = rootDir + "/" + folderDir;
      await createUploadFolderIfMissing(source, rootDir);
      debug(`Folder : ${targettedFolderName} was created on the FoundryVTT system at ${source + "/" + rootDir}`);
    } else if (targetType === "PLAYLIST") {
      targettedImportPlaylist = game.playlists.getName(targettedPlaylistName);
      debug(`Audio Files drag and drop imported in playlist ${targettedPlaylistName}`);
    }
    var sounds = [];
    for (const audioFile of audioFiles) {
      let response = await foundry.applications.apps.FilePicker.implementation.upload(
        source,
        rootDir,
        audioFile,
        {},
        { notify: true }
      );
      var soundName = _PlaylistImporter._convertToUserFriendly(_PlaylistImporter._getBaseName(audioFile.name));
      debug(`Audio file : ${soundName} was drop uploaded to foundryVTT server path : ${source + "/" + rootDir}`);
      sounds.push({ name: soundName, path: response.path, repeat: shouldRepeat, volume: logVolume });
    }
    targettedImportPlaylist.createEmbeddedDocuments("PlaylistSound", sounds);
  }
};
__name(_PlaylistImporter, "PlaylistImporter");
let PlaylistImporter = _PlaylistImporter;
PlaylistImporterInitializer.initialize();
//# sourceMappingURL=module.js.map
